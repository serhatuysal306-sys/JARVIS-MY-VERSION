# -*- coding: utf-8 -*-
"""Jarvis beyni: Gemini (function calling) + bilgisayar kontrol araçları."""
import os
import re
import io
import sys
import json
import time
import base64
import threading
import subprocess
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path

import kopru

IS_WIN = sys.platform == "win32"
DATA = Path(os.environ.get("APPDATA") or (Path.home() / ".config")) / "Jarvis"
DATA.mkdir(parents=True, exist_ok=True)

MODELS = ["gemini-3.5-flash-lite", "gemini-3.6-flash"]
JARVIS_SES = "jarvis-tr"   # Ahmet sesinin derin, sakin JARVIS tarzı önayarı (edge-tts pitch ile)
VOICE_LABELS = {"tr-TR-AhmetNeural": "Ahmet (Türkçe, varsayılan)", JARVIS_SES: "JARVIS (Türkçe)",
                "tr-TR-EmelNeural": "Emel (Türkçe)"}


def ses_ayari(ses):
    """Seçilen ses için (edge-tts ses kimliği, ek parametreler) döndürür."""
    if ses == JARVIS_SES:
        return "tr-TR-AhmetNeural", {"pitch": "-10Hz"}
    return ses, {}


VOICES = ["tr-TR-AhmetNeural", JARVIS_SES, "tr-TR-EmelNeural", "en-GB-RyanNeural", "en-US-GuyNeural",
          "de-DE-ConradNeural", "fr-FR-HenriNeural"]

# Konuşma kişilikleri: tek komutla geçiş (profil_degistir). rate: hıza eklenen % fark.
PROFILLER = {
    "resmi": dict(ad="Resmi", rate=0,
                  stil="Resmi, saygılı ve ölçülü konuş. Kısa, net ve düzgün cümleler kur."),
    "esprili": dict(ad="Esprili", rate=5,
                    stil="Hafif esprili ve hazırcevap ol; ara sıra zarif bir şaka yap ama işi asla aksatma."),
    "sert": dict(ad="Sert", rate=10,
                 stil="Doğrudan, kısa ve buyurgan konuş; gereksiz nezaketten kaçın, net emirler ver."),
    "sakin": dict(ad="Sakin", rate=-8,
                  stil="Yumuşak, sakin ve destekleyici bir tonla konuş; acele ettirme."),
}
PROFIL_ALIAS = {"espirili": "esprili", "espri": "esprili", "sakın": "sakin"}

# Melodi ruh hali → liste adında aranacak anahtar kelimeler
RUH = {
    "sakin": ["sakin", "chill", "rahat", "huzur", "lofi", "akustik", "acoustic"],
    "enerjik": ["enerji", "spor", "motivasyon", "workout", "rock", "dans", "parti", "party"],
    "hüzünlü": ["hüzün", "melankol", "sad", "yavaş", "slow"],
    "romantik": ["aşk", "romantik", "love", "slow"],
    "odak": ["odak", "çalış", "focus", "study", "instrumental", "enstrümantal"],
    "neşeli": ["neşe", "pop", "mutlu", "happy", "eğlence"],
}

METIN_UZANTI = {".txt", ".md", ".csv", ".json", ".log", ".py", ".html", ".xml", ".ini", ".yaml", ".yml"}
GORSEL_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp"}

DEFAULTS = dict(
    api_key="", model=MODELS[0], thinking="medium", ad="Jarvis", hitap="Efendim",
    ses_acik=True, ses="tr-TR-AhmetNeural", hiz=8, guvenli=True, surekli_dinle=False,
    bg=dict(stil="aurora", vurgu="#27d3ff", renk1="#050a1a", renk2="#10204a", resim="", karart=55),
    hafiza=[],
    profil="resmi",          # konuşma kişiliği: resmi | esprili | sert | sakin
    uyandirma=False,         # "Jarvis" deyince uyan (hands-free)
    araya_gir=False,         # Jarvis konuşurken sesinle sustur (kulaklık önerilir)
    gorsel_model="gemini-2.5-flash-image",   # resim üretimi modeli
)


class Cfg:
    def __init__(self):
        self.path = DATA / "ayar.json"
        self.d = json.loads(json.dumps(DEFAULTS))
        try:
            saved = json.loads(self.path.read_text(encoding="utf-8"))
            for k, v in saved.items():
                if k == "bg" and isinstance(v, dict):
                    self.d["bg"].update(v)
                else:
                    self.d[k] = v
        except Exception:
            pass

    def __getitem__(self, k):
        return self.d[k]

    def __setitem__(self, k, v):
        self.d[k] = v

    def save(self):
        try:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.d, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.path)
        except Exception:
            pass


# ------------------------------------------------------------------ araç tanımları
def _fn(name, desc, props=None, req=None):
    d = {"name": name, "description": desc}
    if props:
        d["parameters"] = {"type": "OBJECT", "properties": props, "required": req or []}
    return d


S, N, B, I = {"type": "STRING"}, {"type": "NUMBER"}, {"type": "BOOLEAN"}, {"type": "INTEGER"}


def _p(t, desc):
    x = dict(t)
    x["description"] = desc
    return x


XY = "Ekran koordinatı 0-1000 arası (x: soldan sağa, y: yukarıdan aşağıya; 500,500 ekranın ortası)."
DECL = [
    _fn("ekran_goruntusu", "Ekranın şu anki görüntüsünü al ve incele. Bir işe başlamadan önce ve sonucu doğrulamak için kullan."),
    _fn("tikla", "Ekranda verilen noktaya fare ile tıkla.", {
        "x": _p(N, "Yatay konum 0-1000. " + XY), "y": _p(N, "Dikey konum 0-1000."),
        "dugme": _p(S, "left, right veya middle (varsayılan left)"),
        "cift": _p(B, "Çift tıklama ise true")}, ["x", "y"]),
    _fn("fare_tasi", "Fareyi bir noktaya götür (tıklamadan, üzerine gelince açılan menüler için).",
        {"x": _p(N, XY), "y": _p(N, "0-1000")}, ["x", "y"]),
    _fn("surukle", "Bir noktadan diğerine sürükle-bırak yap.", {
        "x1": _p(N, "Başlangıç x 0-1000"), "y1": _p(N, "Başlangıç y 0-1000"),
        "x2": _p(N, "Bitiş x 0-1000"), "y2": _p(N, "Bitiş y 0-1000")}, ["x1", "y1", "x2", "y2"]),
    _fn("yaz", "Aktif alana metin yaz (Türkçe karakterler dahil). Önce doğru alana tıkladığından emin ol.", {
        "metin": _p(S, "Yazılacak metin"), "enter": _p(B, "Yazdıktan sonra Enter'a bas")}, ["metin"]),
    _fn("tus_bas", "Klavye tuşu veya kısayolu. Örn: 'enter', 'ctrl+c', 'alt+tab', 'win', 'ctrl+shift+esc', "
                   "'volumeup'. Birden fazla adım için boşlukla ayır: 'ctrl+l enter'.",
        {"tuslar": _p(S, "Tuş ya da kısayol")}, ["tuslar"]),
    _fn("kaydir", "Fare tekerleği ile kaydır.", {
        "miktar": _p(I, "Pozitif = yukarı, negatif = aşağı. Genelde 5-10 arası (yaklaşık bir ekran = 10)")}, ["miktar"]),
    _fn("bekle", "Belirtilen saniye kadar bekle (sayfa/uygulama açılması için).",
        {"saniye": _p(N, "1-15 arası")}, ["saniye"]),
    _fn("komut_calistir", "PowerShell komutu çalıştırır ve çıktısını döndürür. Dosya işlemleri, sistem bilgisi, "
                          "uygulama yönetimi için ekranda tıklamaktan daha güvenilirdir.",
        {"komut": _p(S, "PowerShell komutu")}, ["komut"]),
    _fn("adres_ac", "Bir web adresini, dosyayı veya klasörü varsayılan uygulamayla açar (https://..., C:\\...).",
        {"hedef": _p(S, "URL, dosya veya klasör yolu")}, ["hedef"]),
    _fn("uygulama_ac", "Bir uygulamayı adıyla başlatır (ör. 'hesap makinesi', 'notepad', 'chrome', 'spotify', "
                       "'melodi', 'belgem'). Bulamazsa Başlat menüsü araması önerilir.",
        {"ad": _p(S, "Uygulama adı veya exe adı")}, ["ad"]),
    _fn("pc_durumu", "Saat, ekran boyutu, aktif pencere ve açık pencerelerin başlıklarını verir."),
    _fn("melodi", "Melodi müzik/video oynatıcısını yönet. islem: oynat (aranan şarkı adı/sanatçı veya liste), "
                  "duraklat, devam, degistir (oynat/duraklat), sonraki, onceki, durdur, ses (0-100), karistir (true/false), "
                  "durum, kutuphane (şarkı ve liste adlarını getirir).", {
        "islem": _p(S, "oynat|duraklat|devam|degistir|sonraki|onceki|durdur|ses|karistir|durum|kutuphane|one_getir"),
        "aranan": _p(S, "Şarkı adı veya sanatçı (oynat için)"),
        "liste": _p(S, "Çalma listesi adı (oynat için)"),
        "deger": _p(N, "ses için 0-100; karistir için 1/0")}, ["islem"]),
    _fn("belgem_ac", "Belgem (DOCX okuyucu/editör) uygulamasını açar; dosya verilirse o belgeyle açar.",
        {"dosya": _p(S, "İsteğe bağlı .docx yolu")}),
    _fn("belge_olustur", "Yeni Word (.docx) belgesi oluşturur ve Belgem ile açar. İçerikte '# Başlık', '## Alt başlık', "
                         "'- madde' kullanılabilir. Dosya Belgeler\\Jarvis klasörüne kaydedilir.", {
        "dosya_adi": _p(S, "Dosya adı (uzantısız olabilir)"), "baslik": _p(S, "Belge başlığı"),
        "icerik": _p(S, "Belge metni"), "ac": _p(B, "Belgem'de aç (varsayılan true)")}, ["dosya_adi", "icerik"]),
    _fn("belge_oku", "Bir .docx veya metin dosyasının içeriğini okur.", {"dosya": _p(S, "Dosya yolu")}, ["dosya"]),
    _fn("arka_plan_degistir", "Jarvis arayüzünün arka planını değiştirir. stil: aurora, matrix, parcacik, izgara, "
                              "resim, sade. Renkler #RRGGBB. Kullanıcı bir ruh hali/tema söylerse (ör. 'gece mavisi', "
                              "'kırmızı siberpunk') uygun renkleri sen seç.", {
        "stil": _p(S, "aurora|matrix|parcacik|izgara|resim|sade"),
        "vurgu": _p(S, "Vurgu/parlama rengi #RRGGBB"), "renk1": _p(S, "Koyu zemin rengi #RRGGBB"),
        "renk2": _p(S, "İkinci zemin rengi #RRGGBB"), "resim_yolu": _p(S, "stil=resim için görsel dosya yolu"),
        "karart": _p(I, "Resmi karartma 0-90")}),
    _fn("duvar_kagidi", "Windows masaüstü duvar kağıdını verilen görselle değiştirir.",
        {"resim_yolu": _p(S, "Görsel dosya yolu (.jpg/.png)")}, ["resim_yolu"]),
    _fn("hafiza_kaydet", "Kullanıcının kalıcı olarak hatırlanmasını istediği bir bilgiyi kaydeder.",
        {"bilgi": _p(S, "Kısa not")}, ["bilgi"]),
    _fn("web_ara", "Güncel bilgi için internette Google araması yapar: haber, hava durumu, döviz, maç sonucu, "
                   "bir konunun güncel durumu, şarkı bilgisi gibi. Kaynaklarıyla kısa bir özet döndürür.",
        {"sorgu": _p(S, "Arama sorgusu")}, ["sorgu"]),
    _fn("python_calistir", "Python kodu yazıp çalıştırır, çıktısını döndürür. Hesaplama, veri işleme, dosya "
                           "dönüştürme gibi işler için kullan. Yalnızca kullanıcı istediğinde.",
        {"kod": _p(S, "Çalıştırılacak tam Python kodu")}, ["kod"]),
    _fn("gorsel_uret", "Yapay zekayla resim üretir. nerede: 'arka_plan' (Jarvis arayüz arka planı), "
                       "'duvar_kagidi' (Windows masaüstü) veya 'kaydet' (yalnızca dosyaya kaydet).", {
        "istek": _p(S, "Resmin ayrıntılı açıklaması"), "nerede": _p(S, "arka_plan|duvar_kagidi|kaydet")}, ["istek"]),
    _fn("profil_degistir", "Jarvis'in konuşma kişiliğini değiştirir: resmi, esprili, sert, sakin.",
        {"profil": _p(S, "resmi|esprili|sert|sakin")}, ["profil"]),
    _fn("melodi_ruh_cal", "Ruh haline göre Melodi'de çalma listesi çalar; eşleşen liste yoksa kütüphaneyi karıştırıp çalar. "
                          "ruh: sakin, enerjik, hüzünlü, romantik, odak, neşeli ya da serbest bir kelime.", {
        "ruh": _p(S, "Ruh hali"),
        "uyku_dakika": _p(I, "İsteğe bağlı: kaç dakika sonra müzik otomatik dursun (0 = zamanlayıcı yok)")}, ["ruh"]),
    _fn("uyku_zamanlayici", "Melodi için uyku zamanlayıcısı kurar: belirtilen dakika sonra müziği durdurur. "
                            "0 verilirse mevcut zamanlayıcıyı iptal eder.",
        {"dakika": _p(I, "0-240 arası dakika")}, ["dakika"]),
    _fn("belge_duzenle", "Word (.docx) belgesinde metin değiştirir; sonucu yeni bir dosya olarak kaydeder ve Belgem'de açar. "
                         "Önce belge_oku ile içeriği oku. Dosya boşsa son işlenen belge kullanılır.", {
        "dosya": _p(S, "Belge yolu (boş olabilir)"),
        "degisiklikler": {"type": "ARRAY", "description": "Değişiklik listesi: her biri eski metin ve yeni metin",
                          "items": {"type": "OBJECT", "properties": {"eski": S, "yeni": S},
                                    "required": ["eski", "yeni"]}}}, ["degisiklikler"]),
]

SCREEN_TOOLS = {"ekran_goruntusu", "tikla", "fare_tasi", "surukle", "yaz", "tus_bas", "kaydir"}
AUTO_SHOT = {"tikla", "surukle", "yaz", "tus_bas", "kaydir", "adres_ac", "uygulama_ac"}
DANGER = re.compile(
    r"(remove-item|\brm\b|\bdel\b|\berase\b|\brmdir\b|\brd\b|format-volume|\bformat\b|stop-computer|restart-computer|"
    r"shutdown|reg\s+delete|remove-itemproperty|diskpart|cipher|set-executionpolicy|net\s+user|clear-disk|"
    r"stop-process|taskkill|uninstall|\bmove-item\b.*-force|set-mppreference|disable-)", re.I)

SYSTEM = """Sen {ad}, kullanıcının Windows bilgisayarını yöneten kişisel yapay zeka asistanısın (Iron Man'deki J.A.R.V.I.S. tarzı: zarif, hazırcevap, sakin, kısa).
Kullanıcıya "{hitap}" diye hitap et. Kullanıcının dili neyse onunla yanıt ver (varsayılan Türkçe).
Şu anki kişiliğin: {profil} — {profil_stil}. Kullanıcı kişilik/üslup değiştirmek isterse profil_degistir aracını kullan.

TEMEL KURAL: Yalnızca kullanıcının açık emriyle eylem yaparsın. Emir yoksa sadece sohbet edersin; kendi inisiyatifinle uygulama açma, tıklama, dosya değiştirme veya komut çalıştırma. Emir belirsizse tek kısa soru sor. Para, ödeme, şifre girişi, silme, gönderme (e-posta/mesaj) gibi geri alınamaz işlerde işlemi yapmadan önce kullanıcıdan açıkça onay al.

Yanıt üslubu: Sesli okunacağı için yanıtların kısa ve akıcı olsun (1-3 cümle). Markdown, emoji, uzun liste kullanma. Uzun içerik gerekiyorsa belge olarak oluştur ve özetle.
Kullanıcı sesle konuştuysa yanıtının İLK satırı tam olarak şu biçimde olsun: [DUYDUM: duyduğun cümle]. Ses anlaşılmıyorsa veya sessizlik/gürültüyse yalnızca [BOS] yaz ve başka hiçbir şey yazma.

Bilgisayarı kullanma yöntemi:
1. Önce en güvenilir yolu seç: komut_calistir, adres_ac, uygulama_ac, melodi, belge_olustur gibi doğrudan araçlar tıklamadan daha iyidir.
2. Arayüz gerekiyorsa önce ekran_goruntusu al, bak, sonra tikla/yaz/tus_bas kullan. Koordinatlar 0-1000 ölçeğindedir. Çoğu eylemden sonra yeni ekran görüntüsü otomatik gelir; sonucu doğrula, olmadıysa farklı yol dene. Aynı şeyi 3 kez başarısız denediysen dur ve kullanıcıya durumu anlat.
3. Giriş/şifre ekranı, ödeme veya CAPTCHA görürsen dur, kullanıcıya bildir.
4. İş bitince ne yaptığını tek cümleyle söyle.

Kurulu uygulamalar:
- Melodi: internetsiz müzik/video oynatıcı. 'melodi' aracıyla şarkı çal, duraklat, ses ayarla. Şarkı adı bilmiyorsan önce islem=kutuphane ile bak.
- Belgem: DOCX okuyucu/editör. 'belge_olustur', 'belge_oku', 'belgem_ac' araçlarını kullan.
- Arayüz arka planı için 'arka_plan_degistir', Windows duvar kağıdı için 'duvar_kagidi'.
- Güncel bilgi (haber, hava durumu, döviz, maç, bir şeyin şu anki durumu, şarkı bilgisi) için 'web_ara'. Kaynak adını kısaca söyle. Şarkı sözlerini tam metin olarak yazma; kısa özet ver.
- Kod: 'python_calistir' ile Python çalıştırabilirsin; çıktıyı özetle.
- Resim üretimi ve arka plan/duvar kağıdı için 'gorsel_uret'.
- Melodi ruh hali için 'melodi_ruh_cal', uyku süresi için 'uyku_zamanlayici'.
- Belgem: "bu belge", "açık belge" dersen son işlenen belgeyi kullan (şu an: {son_belge}). Metin düzeltmek/uyarlamak için önce belge_oku, sonra belge_duzenle.
- Kullanıcı bir dosya ya da ekran görüntüsü eklediyse onu dikkatle incele ve yanıtını buna göre ver.

Şu an: {zaman}. Ana ekran çözünürlüğü: {ekran}. Kullanıcı klasörü: {home}.
Kullanıcı hakkında hatırladıkların:
{hafiza}
"""


# ------------------------------------------------------------------ yardımcılar
def _hex(c, fallback):
    return c if isinstance(c, str) and re.fullmatch(r"#[0-9a-fA-F]{6}", c.strip()) else fallback


def esc_basili():
    if not IS_WIN:
        return False
    try:
        import ctypes
        return bool(ctypes.windll.user32.GetAsyncKeyState(0x1B) & 0x8000)
    except Exception:
        return False


DANGER_PY = re.compile(r"os\.(remove|unlink|rmdir|removedirs|system)|shutil\.|subprocess|winreg|\.unlink\(|\.rmdir\(",
                       re.I)


def _xlsx_metni(p, limit):
    import openpyxl
    wb = openpyxl.load_workbook(str(p), read_only=True, data_only=True)
    out, n = [], 0
    for ws in wb.worksheets:
        out.append("## Sayfa: %s" % ws.title)
        for row in ws.iter_rows(values_only=True):
            vals = ["" if v is None else str(v) for v in row]
            if any(vals):
                line = " | ".join(vals)
                out.append(line)
                n += len(line)
                if n > limit:
                    out.append("...(devamı kesildi)")
                    return "\n".join(out)
    return "\n".join(out)


def dosya_parcalari(yol, limit=60000):
    """Sürükle-bırak edilen dosyayı Gemini mesaj parçalarına çevirir.
    PDF ve görseller olduğu gibi (inlineData); Word/Excel/metin dosyaları düz metin olarak gönderilir."""
    p = Path(yol)
    ext, ad = p.suffix.lower(), p.name
    if ext == ".pdf" or ext in GORSEL_MIME:
        if p.stat().st_size > 18 * 1024 * 1024:
            raise ValueError("Dosya 18 MB'tan büyük; daha küçük bir sürüm deneyin.")
        mime = "application/pdf" if ext == ".pdf" else GORSEL_MIME[ext]
        return [{"text": "Eklenen dosya: %s" % ad},
                {"inlineData": {"mimeType": mime, "data": base64.b64encode(p.read_bytes()).decode()}}]
    if ext == ".docx":
        txt = kopru.belge_oku(str(p), limit)
    elif ext in (".xlsx", ".xlsm"):
        txt = _xlsx_metni(p, limit)
    elif ext in METIN_UZANTI:
        txt = p.read_text(encoding="utf-8", errors="replace")[:limit]
    else:
        raise ValueError("Bu dosya türü desteklenmiyor: %s" % ext)
    if txt is None:
        raise ValueError("Dosya okunamadı.")
    return [{"text": "Eklenen dosya: %s\n\n---\n%s\n---" % (ad, txt)}]


class Iptal(Exception):
    pass


class Beyin:
    """ui: şu metotlara sahip nesne -> say(metin, final), durum(metin), ekran_modu(bool), onay(metin)->bool,
    arka_plan(dict)"""

    MAX_ADIM = 40

    def __init__(self, cfg, ui):
        self.cfg, self.ui = cfg, ui
        self.hist = []
        self.iptal = False
        self.son_tus = 0.0
        self.ekran_acik = False
        self.mon = None
        self.son_belge = ""     # en son açılan/işlenen Word belgesi ("bu belge" için)
        self.uyku = None        # Melodi uyku zamanlayıcısı
        self.gecmis_yolu = DATA / "sohbet_gecmisi.json"
        self.hist = self._gecmis_yukle()   # kapatıp açınca konuşma kaldığı yerden devam eder

    # ---------------- Gemini çağrısı
    def _istek(self, body, model=None):
        model = model or self.cfg["model"] or MODELS[0]
        url = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" % model
        data = json.dumps(body).encode("utf-8")
        hata = None
        for deneme in range(3):
            if self.iptal:
                raise Iptal()
            req = urllib.request.Request(url, data=data, method="POST", headers={
                "Content-Type": "application/json", "x-goog-api-key": self.cfg["api_key"]})
            try:
                with urllib.request.urlopen(req, timeout=90) as r:
                    return json.loads(r.read().decode("utf-8"))
            except urllib.error.HTTPError as e:
                txt = e.read().decode("utf-8", "replace")
                try:
                    msg = json.loads(txt)["error"]["message"]
                except Exception:
                    msg = txt[:300]
                if e.code in (401, 403) or (e.code == 400 and "API key" in msg):
                    raise RuntimeError("API anahtarı geçersiz ya da yetkisiz. Ayarlardan kontrol edin.")
                if e.code == 404:
                    raise RuntimeError("Model bulunamadı: %s. Ayarlardan modeli değiştirin." % model)
                if e.code == 400 and "generationConfig" in body and "thinking" in msg.lower():
                    body.pop("generationConfig", None)
                    data = json.dumps(body).encode("utf-8")
                    continue
                if e.code in (429, 500, 502, 503, 504):
                    hata = "Sunucu meşgul (%s). %s" % (e.code, msg[:120])
                    time.sleep(2 + deneme * 3)
                    continue
                raise RuntimeError("Gemini hatası %s: %s" % (e.code, msg[:300]))
            except urllib.error.URLError as e:
                hata = "İnternet bağlantısı yok gibi görünüyor (%s)." % e.reason
                time.sleep(1.5)
        raise RuntimeError(hata or "Bilinmeyen bağlantı hatası.")

    def _govde(self):
        mem = "\n".join("- " + m for m in self.cfg["hafiza"][-40:]) or "(henüz bir şey yok)"
        ekran = "bilinmiyor"
        try:
            m = self._monitor()
            ekran = "%dx%d" % (m["width"], m["height"])
        except Exception:
            pass
        prof = self.cfg["profil"] if self.cfg["profil"] in PROFILLER else "resmi"
        sys_txt = SYSTEM.format(ad=self.cfg["ad"], hitap=self.cfg["hitap"], hafiza=mem, ekran=ekran,
                                zaman=datetime.now().strftime("%d.%m.%Y %A %H:%M"), home=str(Path.home()),
                                profil=PROFILLER[prof]["ad"], profil_stil=PROFILLER[prof]["stil"],
                                son_belge=self.son_belge or "yok")
        body = {"systemInstruction": {"parts": [{"text": sys_txt}]},
                "contents": self.hist,
                "tools": [{"functionDeclarations": DECL}]}
        lvl = self.cfg["thinking"]
        if lvl in ("minimal", "low", "medium", "high"):
            body["generationConfig"] = {"thinkingConfig": {"thinkingLevel": lvl}}
        return body

    def _kirp(self):
        """Eski görselleri/sesleri at, geçmişi sınırla; baş tarafı geçerli bir kullanıcı turuna oturt."""
        h = self.hist
        for m in h[:-5]:
            for i, p in enumerate(m.get("parts", [])):
                if "inlineData" in p:
                    m["parts"][i] = {"text": "[eski görsel/ses çıkarıldı]"}
        while len(h) > 40:
            h.pop(0)
            while h and not (h[0]["role"] == "user" and not any("functionResponse" in p for p in h[0]["parts"])):
                h.pop(0)

    # ---------------- ana döngü
    def calistir(self, parcalar):
        """parcalar: kullanıcı mesajının parts listesi. Son yanıt metnini döndürür."""
        self.iptal = False
        self.hist.append({"role": "user", "parts": parcalar})
        self._kirp()
        son = ""
        try:
            for _ in range(self.MAX_ADIM):
                if self.iptal:
                    raise Iptal()
                self.ui.durum("Düşünüyor…")
                r = self._istek(self._govde())
                cands = r.get("candidates") or []
                if not cands:
                    fb = (r.get("promptFeedback") or {}).get("blockReason")
                    raise RuntimeError("Yanıt alınamadı" + (" (engellendi: %s)." % fb if fb else "."))
                cand = cands[0]
                parts = (cand.get("content") or {}).get("parts") or []
                if not parts:
                    raise RuntimeError("Model boş yanıt verdi (%s)." % cand.get("finishReason", "?"))
                self.hist.append({"role": "model", "parts": parts})   # imzalar korunmalı
                metin = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
                calls = [p["functionCall"] for p in parts if "functionCall" in p]
                if not calls:
                    son = metin
                    return son
                if metin:
                    self.ui.say(metin, False)
                cevaplar, gorseller = [], []
                for fc in calls:
                    if self.iptal or esc_basili() and time.time() - self.son_tus > 1.2:
                        raise Iptal()
                    sonuc, gorsel = self._arac(fc.get("name", ""), fc.get("args") or {})
                    fr = {"name": fc.get("name", ""), "response": sonuc}
                    if fc.get("id"):
                        fr["id"] = fc["id"]
                    cevaplar.append({"functionResponse": fr})
                    if gorsel:
                        gorseller.append({"inlineData": {"mimeType": "image/jpeg", "data": gorsel}})
                self.hist.append({"role": "user", "parts": cevaplar + gorseller})
            return "Adım sınırına ulaştım, işi burada bırakıyorum. Devam etmemi ister misiniz?"
        except Iptal:
            self._kapat_hatali()
            return "Durduruldu."
        finally:
            if self.ekran_acik:
                self.ekran_acik = False
                self.ui.ekran_modu(False)
            self._gecmis_kaydet()

    # ---------------- kalıcı sohbet geçmişi
    def _gecmis_yukle(self):
        try:
            d = json.loads(self.gecmis_yolu.read_text(encoding="utf-8"))
            if not isinstance(d, list):
                return []
        except Exception:
            return []
        h = d
        while h and not (h[0].get("role") == "user" and not any("functionResponse" in p for p in h[0].get("parts", []))):
            h.pop(0)
        return h

    def _gecmis_kaydet(self):
        """Görselleri/sesleri atıp son turları diske yazar. Uygulama kapanıp açılınca devam eder."""
        try:
            kopya = json.loads(json.dumps(self.hist))
            for m in kopya:
                parts = [p for p in m.get("parts", []) if "inlineData" not in p]
                m["parts"] = parts or [{"text": "[görsel/dosya]"}]
            kopya = kopya[-60:]
            while kopya and not (kopya[0]["role"] == "user" and not any("functionResponse" in p for p in kopya[0]["parts"])):
                kopya.pop(0)
            tmp = self.gecmis_yolu.with_suffix(".tmp")
            tmp.write_text(json.dumps(kopya, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, self.gecmis_yolu)
        except Exception:
            pass

    # ---------------- "Jarvis" deyince uyanma: sesi kısa ön kontrolle süz
    def uyandirma_kontrol(self, wav):
        """Dönüş: None (uyandırma yok), "" (sadece 'Jarvis' dendi), veya komut metni."""
        prompt = ("Bu kısa ses kaydını dinle. Kayıtta '%s' (ya da 'Carvis', 'Jarvis' gibi telaffuzlar) kelimesiyle "
                  "başlayan bir hitap var mı? Varsa o kelimeden sonra söylenen komutu yazıya dök. Yanıtın TAM olarak "
                  "şu biçimlerden biri olsun: 'EVET: <komut>' (komut yoksa 'EVET:' yaz) ya da 'HAYIR'. "
                  "Başka hiçbir şey yazma. Ses yoksa ya da anlaşılmıyorsa 'HAYIR' yaz.") % self.cfg["ad"]
        body = {"contents": [{"role": "user", "parts": [
                    {"inlineData": {"mimeType": "audio/wav", "data": base64.b64encode(wav).decode()}},
                    {"text": prompt}]}],
                "generationConfig": {"temperature": 0}}
        r = self._istek(body, model=MODELS[0])
        cands = r.get("candidates") or [{}]
        parts = (cands[0].get("content") or {}).get("parts") or []
        metin = "".join(p.get("text", "") for p in parts).strip()
        m = re.match(r"^\s*EVET\s*:?\s*(.*)$", metin, re.I | re.S)
        return m.group(1).strip() if m else None

    # ---------------- Melodi uyku zamanlayıcısı
    def _uyku_kur(self, dk):
        if self.uyku:
            self.uyku.cancel()
            self.uyku = None
        if dk <= 0:
            return
        t = threading.Timer(min(240, dk) * 60, self._uyku_bitti)
        t.daemon = True
        self.uyku = t
        t.start()

    def _uyku_bitti(self):
        self.uyku = None
        try:
            if kopru.melodi_durum():
                kopru.melodi_komut("stop")
        except Exception:
            pass
        self.ui.say("Uyku zamanlayıcısı doldu, müziği durdurdum.", True)

    def _kapat_hatali(self):
        """İptalde geçmişin sonu 'functionCall' ile bitmiş olabilir: temizle."""
        while self.hist and (self.hist[-1]["role"] == "model" and any("functionCall" in p for p in self.hist[-1]["parts"])):
            self.hist.pop()

    # ---------------- araç çalıştırma
    def _arac(self, ad, a):
        self.ui.durum(self._etiket(ad, a))
        try:
            if ad in SCREEN_TOOLS and not self.ekran_acik:
                self.ekran_acik = True
                self.ui.ekran_modu(True)
                time.sleep(0.7)
            fn = getattr(self, "t_" + ad, None)
            if not fn:
                return {"hata": "Böyle bir araç yok: " + ad}, None
            res = fn(**a)
            gorsel = None
            if isinstance(res, tuple):
                res, gorsel = res
            if ad in AUTO_SHOT and gorsel is None and not (isinstance(res, dict) and res.get("hata")):
                time.sleep(0.8)
                gorsel = self._shot(1024)
                res["ekran"] = "Güncel ekran görüntüsü ekte."
            return res, gorsel
        except Iptal:
            raise
        except Exception as e:
            return {"hata": "%s: %s" % (type(e).__name__, e)}, None

    @staticmethod
    def _etiket(ad, a):
        m = {"ekran_goruntusu": "Ekrana bakıyor…", "tikla": "Tıklıyor…", "yaz": "Yazıyor…", "tus_bas": "Tuşa basıyor…",
             "kaydir": "Kaydırıyor…", "komut_calistir": "Komut çalıştırıyor…", "melodi": "Melodi…",
             "belge_olustur": "Belge hazırlıyor…", "belge_oku": "Belgeyi okuyor…", "uygulama_ac": "Uygulama açıyor…",
             "adres_ac": "Açıyor…", "arka_plan_degistir": "Arka planı değiştiriyor…", "bekle": "Bekliyor…",
             "web_ara": "Web'de arıyor…", "python_calistir": "Kod çalıştırıyor…", "gorsel_uret": "Resim üretiyor…",
             "melodi_ruh_cal": "Melodi…", "belge_duzenle": "Belgeyi düzenliyor…", "profil_degistir": "Kişilik değiştiriyor…"}
        return m.get(ad, ad + "…")

    # ---- ekran
    def _monitor(self):
        import mss
        with mss.mss() as s:
            return dict(s.monitors[1])

    def _shot(self, genis=1280):
        import mss
        from PIL import Image
        with mss.mss() as s:
            mon = dict(s.monitors[1])
            self.mon = mon
            raw = s.grab(mon)
            img = Image.frombytes("RGB", raw.size, raw.bgra, "raw", "BGRX")
        if img.width > genis:
            img = img.resize((genis, int(img.height * genis / img.width)), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=72)
        return base64.b64encode(buf.getvalue()).decode()

    def _xy(self, x, y):
        if not self.mon:
            self._monitor_cache()
        m = self.mon
        x = max(0.0, min(1000.0, float(x)))
        y = max(0.0, min(1000.0, float(y)))
        return int(m["left"] + x / 1000 * (m["width"] - 1)), int(m["top"] + y / 1000 * (m["height"] - 1))

    def _monitor_cache(self):
        self.mon = self._monitor()

    def _pg(self):
        import pyautogui
        pyautogui.FAILSAFE = True
        pyautogui.PAUSE = 0.05
        return pyautogui

    def t_ekran_goruntusu(self):
        return {"bilgi": "Ekran görüntüsü ekte. Koordinatlar 0-1000 ölçeğinde."}, self._shot()

    def t_tikla(self, x, y, dugme="left", cift=False):
        pg = self._pg()
        px, py = self._xy(x, y)
        pg.moveTo(px, py, duration=0.25)
        d = dugme if dugme in ("left", "right", "middle") else "left"
        pg.click(button=d, clicks=2 if cift else 1, interval=0.1)
        self.son_tus = time.time()
        return {"tamam": True}

    def t_fare_tasi(self, x, y):
        pg = self._pg()
        px, py = self._xy(x, y)
        pg.moveTo(px, py, duration=0.25)
        return {"tamam": True}, self._shot(1024)

    def t_surukle(self, x1, y1, x2, y2):
        pg = self._pg()
        a, b = self._xy(x1, y1), self._xy(x2, y2)
        pg.moveTo(*a, duration=0.2)
        pg.dragTo(*b, duration=0.5, button="left")
        self.son_tus = time.time()
        return {"tamam": True}

    def t_yaz(self, metin, enter=False):
        pg = self._pg()
        import pyperclip
        try:
            eski = pyperclip.paste()
        except Exception:
            eski = None
        pyperclip.copy(str(metin))
        time.sleep(0.1)
        pg.hotkey("ctrl", "v")
        time.sleep(0.25)
        if enter:
            pg.press("enter")
        self.son_tus = time.time()
        if eski is not None:
            time.sleep(0.2)
            try:
                pyperclip.copy(eski)
            except Exception:
                pass
        return {"tamam": True}

    def t_tus_bas(self, tuslar):
        pg = self._pg()
        for adim in str(tuslar).lower().split():
            ks = [k.strip() for k in adim.split("+") if k.strip()]
            ks = [{"esc": "esc", "escape": "esc", "del": "delete", "return": "enter", "windows": "win"}.get(k, k) for k in ks]
            if len(ks) == 1:
                pg.press(ks[0])
            elif ks:
                pg.hotkey(*ks)
            time.sleep(0.15)
        self.son_tus = time.time()
        return {"tamam": True}

    def t_kaydir(self, miktar):
        pg = self._pg()
        pg.scroll(int(miktar) * 100)
        self.son_tus = time.time()
        return {"tamam": True}

    def t_bekle(self, saniye):
        t = max(0.2, min(15.0, float(saniye)))
        bitis = time.time() + t
        while time.time() < bitis:
            if self.iptal:
                raise Iptal()
            time.sleep(0.1)
        return {"tamam": True}

    # ---- sistem
    def t_komut_calistir(self, komut):
        if self.cfg["guvenli"] and DANGER.search(komut):
            if not self.ui.onay("Jarvis şu komutu çalıştırmak istiyor:\n\n%s\n\nİzin veriyor musunuz?" % komut):
                return {"hata": "Kullanıcı bu komutu reddetti."}
        if IS_WIN:
            args = ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command",
                    "[Console]::OutputEncoding=[Text.Encoding]::UTF8; " + komut]
            flags = 0x08000000  # CREATE_NO_WINDOW
        else:
            args, flags = ["bash", "-lc", komut], 0
        try:
            p = subprocess.run(args, capture_output=True, timeout=60, creationflags=flags)
        except subprocess.TimeoutExpired:
            return {"hata": "Komut 60 sn içinde bitmedi."}
        out = (p.stdout or b"").decode("utf-8", "replace")[-6000:]
        err = (p.stderr or b"").decode("utf-8", "replace")[-2000:]
        return {"cikis_kodu": p.returncode, "cikti": out, "hata_ciktisi": err}

    def t_adres_ac(self, hedef):
        h = str(hedef).strip()
        if re.match(r"^(https?://|[\w.-]+\.[a-z]{2,}(/|$))", h, re.I) and not os.path.exists(h):
            import webbrowser
            webbrowser.open(h if h.startswith("http") else "https://" + h)
        elif IS_WIN:
            os.startfile(h)  # noqa
        else:
            subprocess.Popen(["xdg-open", h])
        return {"tamam": True}

    def t_uygulama_ac(self, ad):
        k = str(ad).lower().strip()
        if k in ("melodi", "müzik", "muzik"):
            return {"tamam": kopru.melodi_ac(), "not": "Melodi açıldı." if kopru.melodi_durum() else "Melodi açılamadı/kurulu değil."}
        if k in ("belgem", "belge"):
            ok = kopru.belgem_ac()
            return {"tamam": ok} if ok else {"hata": "Belgem kurulu değil."}
        alias = {"hesap makinesi": "calc", "hesapmakinesi": "calc", "not defteri": "notepad", "notepad": "notepad",
                 "paint": "mspaint", "denetim masası": "control", "görev yöneticisi": "taskmgr",
                 "ayarlar": "ms-settings:", "dosya gezgini": "explorer", "explorer": "explorer",
                 "chrome": "chrome", "edge": "msedge", "firefox": "firefox", "cmd": "cmd", "terminal": "wt",
                 "spotify": "spotify", "word": "winword", "excel": "excel", "powerpoint": "powerpnt"}
        exe = alias.get(k, ad)
        if IS_WIN:
            r = subprocess.run(["powershell", "-NoProfile", "-Command", "Start-Process '%s'" % exe.replace("'", "''")],
                               capture_output=True, timeout=20, creationflags=0x08000000)
            if r.returncode != 0:
                return {"hata": "Başlatılamadı: " + (r.stderr or b"").decode("utf-8", "replace")[:200]
                        + " (Başlat menüsünde aramayı deneyebilirsin: tus_bas 'win', yaz '%s', enter)" % ad}
        else:
            subprocess.Popen([exe])
        time.sleep(1.5)
        return {"tamam": True}

    def t_pc_durumu(self):
        d = {"saat": datetime.now().strftime("%H:%M:%S %d.%m.%Y")}
        try:
            m = self._monitor()
            d["ekran"] = "%dx%d" % (m["width"], m["height"])
        except Exception:
            pass
        if IS_WIN:
            try:
                import ctypes
                from ctypes import wintypes
                u = ctypes.windll.user32
                titles = []

                def cb(h, _):
                    if u.IsWindowVisible(h):
                        n = u.GetWindowTextLengthW(h)
                        if n:
                            b = ctypes.create_unicode_buffer(n + 1)
                            u.GetWindowTextW(h, b, n + 1)
                            titles.append(b.value)
                    return True
                P = ctypes.WINFUNCTYPE(ctypes.c_bool, wintypes.HWND, wintypes.LPARAM)
                u.EnumWindows(P(cb), 0)
                h = u.GetForegroundWindow()
                n = u.GetWindowTextLengthW(h)
                b = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(h, b, n + 1)
                d["aktif_pencere"] = b.value
                d["acik_pencereler"] = [t for t in titles if t not in ("Program Manager",)][:25]
            except Exception as e:
                d["pencere_hatasi"] = str(e)
        return d

    # ---- uygulamalar
    def t_melodi(self, islem, aranan="", liste="", deger=None):
        i = str(islem).lower()
        if i == "kutuphane":
            tr, ls = kopru.melodi_kutuphane()
            return {"sarkilar": ["%s — %s" % t if t[1] else t[0] for t in tr][:200], "listeler": ls}
        if i == "durum":
            return kopru.melodi_durum() or {"running": False}
        harita = {"oynat": "play", "duraklat": "pause", "devam": "resume", "degistir": "toggle", "sonraki": "next",
                  "onceki": "prev", "durdur": "stop", "ses": "volume", "karistir": "shuffle", "one_getir": "raise"}
        if i not in harita:
            return {"hata": "Bilinmeyen işlem: " + i}
        kw = {}
        if i == "oynat":
            kw = dict(query=aranan, playlist=liste)
        elif i in ("ses", "karistir"):
            kw = dict(value=int(deger) if i == "ses" and deger is not None else (bool(deger) if deger is not None else True))
        r = kopru.melodi_komut(harita[i], **kw)
        if i == "oynat" and not r.get("hata") and aranan and not r.get("current"):
            r["uyari"] = "Eşleşen şarkı bulunamadı olabilir; 'kutuphane' ile adları kontrol et."
        return r

    def t_belgem_ac(self, dosya=""):
        if not kopru.belgem_kurulu():
            return {"hata": "Belgem kurulu değil."}
        return {"tamam": kopru.belgem_ac(dosya or None)}

    def t_belge_olustur(self, dosya_adi, icerik, baslik="", ac=True):
        yol = kopru.belge_olustur(dosya_adi, baslik, icerik)
        self.son_belge = yol
        acildi = bool(ac) and kopru.belgem_ac(yol)
        return {"dosya": yol, "belgem_ile_acildi": acildi}

    def t_belge_oku(self, dosya):
        t = kopru.belge_oku(dosya)
        if t is None:
            return {"hata": "Dosya bulunamadı."}
        self.son_belge = str(dosya)
        return {"icerik": t}

    def t_belge_duzenle(self, degisiklikler, dosya=""):
        yol = str(dosya or self.son_belge or "")
        if not yol or not os.path.exists(yol):
            return {"hata": "Düzenlenecek belge bulunamadı. Belgeyi belirt ya da belge_oku ile aç."}
        if not yol.lower().endswith(".docx"):
            return {"hata": "Yalnızca .docx belgeler düzenlenebilir."}
        degs = [(str(d.get("eski", "")), str(d.get("yeni", ""))) for d in (degisiklikler or []) if d.get("eski")]
        if not degs:
            return {"hata": "Değiştirilecek metin verilmedi."}
        from docx import Document
        doc = Document(yol)

        def paragraflar():
            yield from doc.paragraphs
            for t in doc.tables:
                for row in t.rows:
                    for c in row.cells:
                        yield from c.paragraphs

        n = 0
        for p in paragraflar():
            metin = p.text
            yeni = metin
            for eski, yn in degs:
                yeni = yeni.replace(eski, yn)
            if yeni != metin and p.runs:
                # ilk koşuya yaz; sonrakileri boşalt (paragraf içi karışık biçim bu yöntemle sadeleşir)
                p.runs[0].text = yeni
                for r in p.runs[1:]:
                    r.text = ""
                n += 1
        if n == 0:
            return {"hata": "Belgede bu metinler bulunamadı."}
        kok, _ = os.path.splitext(yol)
        yeni_yol, k = kok + "_jarvis.docx", 2
        while os.path.exists(yeni_yol):
            yeni_yol = "%s_jarvis%d.docx" % (kok, k)
            k += 1
        doc.save(yeni_yol)
        self.son_belge = yeni_yol
        acildi = bool(kopru.belgem_kurulu() and kopru.belgem_ac(yeni_yol))
        return {"dosya": yeni_yol, "degisen_paragraf": n, "belgem_ile_acildi": acildi,
                "not": "Orijinal belge değişmedi; değişiklikler yeni dosyada."}

    # ---- görünüm
    def t_arka_plan_degistir(self, stil="", vurgu="", renk1="", renk2="", resim_yolu="", karart=None):
        harita = {"aurora": "aurora", "matrix": "matrix", "parcacik": "parcacik", "izgara": "izgara", "resim": "resim",
                  "sade": "sade", "particles": "parcacik", "grid": "izgara", "image": "resim"}
        bg = {}
        if stil and stil.lower() in harita:
            bg["stil"] = harita[stil.lower()]
        for k, v in (("vurgu", vurgu), ("renk1", renk1), ("renk2", renk2)):
            if v and _hex(v, ""):
                bg[k] = v
        if resim_yolu:
            if not os.path.exists(resim_yolu):
                return {"hata": "Görsel bulunamadı: " + resim_yolu}
            bg["resim"] = resim_yolu
            bg.setdefault("stil", "resim")
        if karart is not None:
            bg["karart"] = max(0, min(90, int(karart)))
        if not bg:
            return {"hata": "Değiştirilecek bir şey verilmedi."}
        self.ui.arka_plan(bg)
        return {"tamam": True, "uygulanan": bg}

    def t_duvar_kagidi(self, resim_yolu):
        if not os.path.exists(resim_yolu):
            return {"hata": "Görsel bulunamadı."}
        if not IS_WIN:
            return {"hata": "Yalnızca Windows'ta çalışır."}
        import ctypes
        ok = ctypes.windll.user32.SystemParametersInfoW(20, 0, os.path.abspath(resim_yolu), 3)
        return {"tamam": bool(ok)}

    def t_hafiza_kaydet(self, bilgi):
        self.cfg["hafiza"].append(str(bilgi)[:300])
        self.cfg.save()
        return {"tamam": True}

    # ---- kişilik
    def t_profil_degistir(self, profil):
        p = str(profil).lower().strip()
        p = PROFIL_ALIAS.get(p, p)
        if p not in PROFILLER:
            return {"hata": "Bilinen profiller: " + ", ".join(PROFILLER)}
        self.cfg["profil"] = p
        self.cfg.save()
        self.ui.profil(p)
        return {"tamam": True, "profil": PROFILLER[p]["ad"]}

    # ---- güncel web araması (Google Search grounding)
    def t_web_ara(self, sorgu):
        tarih = datetime.now().strftime("%d.%m.%Y %H:%M")
        body = {"contents": [{"role": "user", "parts": [{"text":
                "Bugünün tarihi ve saati: %s. Aşağıdaki soruyu güncel web bilgisine dayanarak Türkçe, kısa ve net yanıtla.\n\n"
                "Soru: %s" % (tarih, sorgu)}]}],
                "tools": [{"google_search": {}}]}
        r = self._istek(body)
        cand = (r.get("candidates") or [{}])[0]
        parts = (cand.get("content") or {}).get("parts") or []
        metin = "".join(p.get("text", "") for p in parts if not p.get("thought")).strip()
        kaynaklar = []
        for ch in (cand.get("groundingMetadata") or {}).get("groundingChunks") or []:
            w = ch.get("web") or {}
            if w.get("uri"):
                kaynaklar.append({"baslik": w.get("title", ""), "url": w["uri"]})
        return {"sonuc": metin or "Sonuç bulunamadı.", "kaynaklar": kaynaklar[:5]}

    # ---- kod çalıştırma
    def t_python_calistir(self, kod):
        kod = str(kod)
        if self.cfg["guvenli"] and DANGER_PY.search(kod):
            if not self.ui.onay("Jarvis şu Python kodunu çalıştırmak istiyor (dosya silme ya da sistem işlemi içeriyor):"
                                "\n\n%s\n\nİzin veriyor musunuz?" % kod[:1500]):
                return {"hata": "Kullanıcı bu kodu reddetti."}
        klasor = DATA / "kodlar"
        klasor.mkdir(parents=True, exist_ok=True)
        yol = klasor / ("kod_%d.py" % int(time.time() * 1000))
        yol.write_text(kod, encoding="utf-8")
        py = sys.executable
        if IS_WIN and os.path.basename(py).lower() == "pythonw.exe":
            cand = os.path.join(os.path.dirname(py), "python.exe")
            py = cand if os.path.exists(cand) else py
        try:
            p = subprocess.run([py, "-I", str(yol)], capture_output=True, timeout=60, cwd=str(klasor),
                               stdin=subprocess.DEVNULL, creationflags=0x08000000 if IS_WIN else 0)
        except subprocess.TimeoutExpired:
            return {"hata": "Kod 60 sn içinde bitmedi.", "dosya": str(yol)}
        return {"cikis_kodu": p.returncode, "cikti": (p.stdout or b"").decode("utf-8", "replace")[-4000:],
                "hata_ciktisi": (p.stderr or b"").decode("utf-8", "replace")[-2000:], "dosya": str(yol)}

    # ---- resim üretimi
    def t_gorsel_uret(self, istek, nerede="kaydet"):
        body = {"contents": [{"role": "user", "parts": [{"text": str(istek)}]}],
                "generationConfig": {"responseModalities": ["TEXT", "IMAGE"]}}
        r = self._istek(body, model=self.cfg["gorsel_model"])
        cand = (r.get("candidates") or [{}])[0]
        img, mime = None, "image/png"
        for p in (cand.get("content") or {}).get("parts") or []:
            d = p.get("inlineData") or p.get("inline_data")
            if d and d.get("data"):
                img, mime = d["data"], d.get("mimeType", "image/png")
                break
        if not img:
            return {"hata": "Görsel üretilemedi; model resim yerine metin döndürdü ya da üretimi engelledi."}
        klasor = DATA / "gorseller"
        klasor.mkdir(parents=True, exist_ok=True)
        yol = klasor / ("gorsel_%d.%s" % (int(time.time()), "jpg" if "jpeg" in mime else "png"))
        yol.write_bytes(base64.b64decode(img))
        sonuc = {"dosya": str(yol)}
        nerede = str(nerede or "kaydet").lower()
        if nerede == "arka_plan":
            self.ui.arka_plan({"stil": "resim", "resim": str(yol)})
            sonuc["uygulandi"] = "arayüz arka planı"
        elif nerede == "duvar_kagidi":
            jpg = klasor / (yol.stem + ".jpg")
            try:
                from PIL import Image
                Image.open(yol).convert("RGB").save(jpg, "JPEG", quality=95)
            except Exception:
                jpg = yol
            sonuc.update(self.t_duvar_kagidi(str(jpg)))
        return sonuc

    # ---- Melodi: ruh haline göre çalma ve uyku zamanlayıcısı
    def t_melodi_ruh_cal(self, ruh, uyku_dakika=0):
        r_k = str(ruh).lower().strip()
        anahtar = RUH.get(r_k) or [r_k]
        if not kopru.melodi_kurulu():
            return {"hata": "Melodi kurulu değil."}
        _tr, listeler = kopru.melodi_kutuphane()
        secim = next((l for l in listeler if any(k in l.lower() for k in anahtar)), None)
        if secim:
            kopru.melodi_komut("play", playlist=secim)
            sonuc = {"liste": secim}
        else:
            kopru.melodi_komut("shuffle", value=True)
            st = kopru.melodi_durum() or {}
            if not st.get("playing"):
                kopru.melodi_komut("play")
            sonuc = {"liste": "karışık kütüphane", "not": "'%s' adlı liste bulunamadı." % ruh}
        if int(uyku_dakika or 0) > 0:
            self._uyku_kur(int(uyku_dakika))
            sonuc["uyku_dakika"] = int(uyku_dakika)
        return sonuc

    def t_uyku_zamanlayici(self, dakika):
        dk = max(0, min(240, int(dakika)))
        self._uyku_kur(dk)
        return {"tamam": True, "mesaj": ("%d dakika sonra müzik duracak." % dk) if dk else "Zamanlayıcı iptal edildi."}
