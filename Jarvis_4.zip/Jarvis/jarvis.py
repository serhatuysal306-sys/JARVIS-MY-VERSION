# -*- coding: utf-8 -*-
"""J.A.R.V.I.S. — Gemini destekli, sesli/yazılı kişisel bilgisayar asistanı (PyQt6)."""
import os
import sys
import io
import json
import time
import math
import wave
import base64
import random
import threading
import traceback
import subprocess
import tempfile
from pathlib import Path

from PyQt6.QtCore import (Qt, QTimer, QObject, pyqtSignal, QPointF, QRectF, QUrl, QPropertyAnimation, QSize)
from PyQt6.QtGui import (QPainter, QColor, QLinearGradient, QRadialGradient, QPen, QBrush, QFont, QPixmap, QIcon,
                         QPainterPath, QPolygonF, QImage, QFontMetrics, QShortcut, QKeySequence)
from PyQt6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QLineEdit,
                             QScrollArea, QFrame, QDialog, QFormLayout, QComboBox, QCheckBox, QSpinBox, QColorDialog,
                             QFileDialog, QSlider, QMessageBox, QGridLayout, QSizeGrip, QGraphicsOpacityEffect)

import beyin
import kopru
from beyin import Cfg, Beyin, DATA, MODELS, VOICES, VOICE_LABELS, PROFILLER, esc_basili, dosya_parcalari, ses_ayari

APP_NAME = "J.A.R.V.I.S."
IS_WIN = sys.platform == "win32"

DURUM = {"idle": "Emrinizi bekliyorum", "listening": "Dinliyorum…", "thinking": "Düşünüyor…",
         "acting": "Çalışıyor…", "speaking": "Konuşuyor…"}
STATE_COL = {"listening": "#3dffb0", "acting": "#ffb43d"}

TEMALAR = {
    "Siber Mavi": dict(stil="aurora", vurgu="#27d3ff", renk1="#050a1a", renk2="#10204a"),
    "Kızıl Protokol": dict(stil="izgara", vurgu="#ff3b4e", renk1="#14040a", renk2="#3a0a1c"),
    "Zümrüt Matrix": dict(stil="matrix", vurgu="#2cff8a", renk1="#020a06", renk2="#06210f"),
    "Mor Gece": dict(stil="parcacik", vurgu="#b06bff", renk1="#0a0618", renk2="#241048"),
    "Altın Çağ": dict(stil="aurora", vurgu="#ffc247", renk1="#0d0a05", renk2="#2e2108"),
    "Mat Siyah": dict(stil="sade", vurgu="#e6edf7", renk1="#050505", renk2="#16181d"),
}
STILLER = [("aurora", "Aurora"), ("parcacik", "Parçacık"), ("izgara", "İzgara"), ("matrix", "Matrix"),
           ("resim", "Resim"), ("sade", "Sade")]


def qc(h, a=None):
    c = QColor(h)
    if a is not None:
        c.setAlphaF(a)
    return c


def rgba(h, a):
    c = QColor(h)
    return "rgba(%d,%d,%d,%d)" % (c.red(), c.green(), c.blue(), int(a * 255))


def mix(a, b, t):
    a, b = QColor(a), QColor(b)
    return QColor(int(a.red() + (b.red() - a.red()) * t), int(a.green() + (b.green() - a.green()) * t),
                  int(a.blue() + (b.blue() - a.blue()) * t))


# ====================================================================== ARKA PLAN
class Canvas(QWidget):
    """Animasyonlu arka plan; tüm arayüz bunun üstünde durur."""

    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.t = 0.0
        self.radius = 18
        self.rng = random.Random(11)
        self.parts = [[self.rng.random(), self.rng.random(), self.rng.uniform(-.02, .02), self.rng.uniform(-.02, .02)]
                      for _ in range(70)]
        self.stars = [(self.rng.random(), self.rng.random() * .5, self.rng.random()) for _ in range(90)]
        self.cols, self.buf, self.img, self.img_path = [], None, None, None
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(33)

    def bg(self):
        return self.cfg["bg"]

    def tick(self):
        if not self.isVisible():
            return
        self.t += 0.033
        if self.bg()["stil"] == "matrix":
            self.step_matrix()
        self.update()

    def resizeEvent(self, e):
        self.buf = None
        self.cols = []
        super().resizeEvent(e)

    # ---- matrix
    def step_matrix(self):
        w, h = max(self.width(), 2), max(self.height(), 2)
        cw = 18
        if self.buf is None or self.buf.size() != self.size():
            self.buf = QPixmap(self.size())
            self.buf.fill(qc(self.bg()["renk1"]))
            self.cols = [self.rng.uniform(-40, 0) for _ in range(w // cw + 1)]
        p = QPainter(self.buf)
        p.fillRect(0, 0, w, h, qc(self.bg()["renk1"], 0.16))
        f = QFont("Consolas", 12)
        f.setBold(True)
        p.setFont(f)
        acc = qc(self.bg()["vurgu"])
        chars = "01アイウエオカキクケコサシスセソタチツテトナニヌネノ#$%&"
        for i, y in enumerate(self.cols):
            ch = self.rng.choice(chars)
            p.setPen(mix(acc, QColor("white"), .75))
            p.drawText(i * cw, int(y * cw), ch)
            p.setPen(acc)
            p.drawText(i * cw, int((y - 1) * cw), self.rng.choice(chars))
            self.cols[i] = y + 0.55 if y * cw < h or self.rng.random() < .02 else self.rng.uniform(-20, 0)
        p.end()

    # ---- çizim
    def paintEvent(self, e):
        w, h = self.width(), self.height()
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        path = QPainterPath()
        path.addRoundedRect(QRectF(0, 0, w, h), self.radius, self.radius)
        p.setClipPath(path)
        b = self.bg()
        c1, c2, acc = qc(b["renk1"]), qc(b["renk2"]), qc(b["vurgu"])
        stil = b["stil"]
        t = self.t
        if stil == "resim" and self.draw_image(p, w, h, b):
            pass
        elif stil == "matrix" and self.buf is not None:
            p.drawPixmap(0, 0, self.buf)
        else:
            g = QLinearGradient(0, 0, w * .6, h)
            g.setColorAt(0, c1)
            g.setColorAt(1, c2)
            p.fillRect(0, 0, w, h, g)
            if stil == "aurora" or stil == "resim":
                self.paint_aurora(p, w, h, acc, c2, t)
            elif stil == "parcacik":
                self.paint_particles(p, w, h, acc)
            elif stil == "izgara":
                self.paint_grid(p, w, h, acc, t)
        # vinyet
        v = QRadialGradient(w / 2, h / 2, max(w, h) * .75)
        v.setColorAt(0.55, QColor(0, 0, 0, 0))
        v.setColorAt(1, QColor(0, 0, 0, 150))
        p.fillRect(0, 0, w, h, v)
        # ince çerçeve
        p.setClipping(False)
        p.setPen(QPen(qc(b["vurgu"], .28), 1))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(QRectF(.5, .5, w - 1, h - 1), self.radius, self.radius)

    def paint_aurora(self, p, w, h, acc, c2, t):
        for i in range(4):
            cx = w * (.5 + .42 * math.sin(t * .13 + i * 1.7))
            cy = h * (.5 + .38 * math.cos(t * .10 + i * 2.3))
            r = max(w, h) * (.38 + .07 * math.sin(t * .21 + i))
            col = QColor(acc) if i % 2 == 0 else mix(acc, QColor("#8a5bff"), .6)
            g = QRadialGradient(cx, cy, r)
            col.setAlphaF(.30)
            g.setColorAt(0, col)
            col.setAlphaF(0)
            g.setColorAt(1, col)
            p.fillRect(0, 0, w, h, g)

    def paint_particles(self, p, w, h, acc):
        pts = []
        for q in self.parts:
            q[0] = (q[0] + q[2] * .033) % 1
            q[1] = (q[1] + q[3] * .033) % 1
            pts.append((q[0] * w, q[1] * h))
        for i, (x1, y1) in enumerate(pts):
            for x2, y2 in pts[i + 1:]:
                d = math.hypot(x1 - x2, y1 - y2)
                if d < 150:
                    p.setPen(QPen(qc(acc.name(), .35 * (1 - d / 150)), 1))
                    p.drawLine(QPointF(x1, y1), QPointF(x2, y2))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(qc(acc.name(), .9))
        for x, y in pts:
            p.drawEllipse(QPointF(x, y), 2, 2)

    def paint_grid(self, p, w, h, acc, t):
        hor = h * .56
        for sx, sy, sb in self.stars:
            p.setPen(QPen(QColor(255, 255, 255, int(70 + 120 * abs(math.sin(t * .8 + sb * 9)))), 1.4))
            p.drawPoint(QPointF(sx * w, sy * h))
        g = QRadialGradient(w / 2, hor, w * .45)
        a = QColor(acc)
        a.setAlphaF(.55)
        g.setColorAt(0, a)
        a.setAlphaF(0)
        g.setColorAt(1, a)
        p.fillRect(0, int(hor - w * .3), w, int(w * .6), g)
        p.fillRect(0, int(hor), w, int(h - hor), QColor(0, 0, 0, 110))
        pen = QPen(qc(acc.name(), .55), 1.2)
        p.setPen(pen)
        for k in range(-16, 17):
            p.drawLine(QPointF(w / 2 + k * w * .02, hor), QPointF(w / 2 + k * w * .17, h))
        n = 14
        off = (t * .5) % 1
        for k in range(n):
            z = (k + off) / n
            y = hor + (h - hor) * z ** 2.2
            p.setPen(QPen(qc(acc.name(), .15 + .5 * z), 1.2))
            p.drawLine(QPointF(0, y), QPointF(w, y))
        p.setPen(QPen(qc(acc.name(), .9), 1.6))
        p.drawLine(QPointF(0, hor), QPointF(w, hor))

    def draw_image(self, p, w, h, b):
        path = b.get("resim") or ""
        if path != self.img_path:
            self.img_path = path
            im = QImage(path) if path and os.path.exists(path) else QImage()
            self.img = None if im.isNull() else im
        if self.img is None:
            return False
        s = self.img.size().scaled(w, h, Qt.AspectRatioMode.KeepAspectRatioByExpanding)
        p.drawImage(QRectF((w - s.width()) / 2, (h - s.height()) / 2, s.width(), s.height()), self.img)
        p.fillRect(0, 0, w, h, QColor(0, 0, 0, int(255 * b.get("karart", 55) / 100)))
        return True


# ====================================================================== ORB
class MuzikAnaliz:
    """Melodi çalarken orb'u müziğe göre dalgalandırır.
    Windows'ta sistem ses çıkışını (WASAPI loopback) ölçer. Ölçüm kullanılamazsa ritmik bir yedek kullanır."""

    def __init__(self):
        self.v, self.th, self.stop = 0.0, None, None

    def basla(self):
        if self.th and self.th.is_alive():
            return
        self.stop = threading.Event()
        self.th = threading.Thread(target=self._run, args=(self.stop,), daemon=True)
        self.th.start()

    def dur(self):
        if self.stop:
            self.stop.set()
        self.v = 0.0

    def _run(self, stop):
        t0 = time.time()
        try:
            import sounddevice as sd
            import numpy as np
            if not IS_WIN:
                raise RuntimeError("loopback yalnızca Windows'ta")
            aygit = sd.default.device[1]
            hz = int(sd.query_devices(aygit)["default_samplerate"])
            ex = sd.WasapiSettings(loopback=True)
            with sd.InputStream(device=aygit, channels=2, samplerate=hz, dtype="float32",
                                blocksize=1024, extra_settings=ex) as st:
                while not stop.is_set():
                    d, _o = st.read(1024)
                    rms = float(np.sqrt(np.mean(d ** 2)))
                    self.v = self.v * .55 + min(1.0, rms * 7) * .45
        except Exception:
            while not stop.is_set():   # yedek: ~120 BPM ritim
                t = time.time() - t0
                beat = max(0.0, math.sin(t * math.pi * 2 * 2.0)) ** 3
                self.v = .18 + .55 * beat + .1 * abs(math.sin(t * 7.3))
                stop.wait(0.03)
        self.v = 0.0


class Orb(QWidget):
    def __init__(self, cfg):
        super().__init__()
        self.cfg, self.state, self.level, self._lv, self.phase = cfg, "idle", 0.0, 0.0, 0.0
        self.muzik = None   # MuzikAnaliz; Melodi çalarken atanır
        self.setMinimumSize(120, 120)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.tick)
        self.timer.start(33)

    def set_state(self, s):
        self.state = s

    def tick(self):
        if not self.isVisible():
            return
        sp = {"idle": .45, "listening": .9, "thinking": 2.6, "acting": 1.7, "speaking": 1.2}[self.state]
        self.phase += .033 * sp
        tgt = self.level
        if self.state == "speaking":
            tgt = .3 + .45 * abs(math.sin(self.phase * 4.1)) * abs(math.sin(self.phase * 1.7 + .6))
        elif self.state == "thinking":
            tgt = .12 + .08 * math.sin(self.phase * 3)
        if self.muzik is not None:
            tgt = max(tgt, self.muzik.v)
        self._lv += (tgt - self._lv) * .28
        self.update()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        s = min(w, h)
        cx, cy, R = w / 2, h / 2, s * .31
        base = QColor(self.cfg["bg"]["vurgu"])
        col = QColor(STATE_COL[self.state]) if self.state in STATE_COL else base
        if self.state == "idle":
            col = mix(col, QColor("#10182a"), .25)
        lv, ph = self._lv, self.phase
        # parıltı
        gr = min(R * 2.1, s / 2)
        g = QRadialGradient(cx, cy, gr)
        c = QColor(col)
        c.setAlphaF(.30 + .30 * lv)
        g.setColorAt(0, c)
        c.setAlphaF(0)
        g.setColorAt(1, c)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(g)
        p.drawEllipse(QPointF(cx, cy), gr, gr)
        # dış çentikler (ses halkası)
        n = 72
        for i in range(n):
            a = i / n * 2 * math.pi + ph * .08
            k = abs(math.sin(ph * 3 + i * .73)) * (.25 + lv * 1.2)
            r1, r2 = R * 1.22, R * (1.30 + .20 * min(1.0, k))
            cc = QColor(col)
            cc.setAlphaF(.35 + .5 * min(1.0, k))
            p.setPen(QPen(cc, max(1.2, s * .006), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
            p.drawLine(QPointF(cx + r1 * math.cos(a), cy + r1 * math.sin(a)),
                       QPointF(cx + r2 * math.cos(a), cy + r2 * math.sin(a)))
        # kesikli halka
        pen = QPen(qc(col.name(), .7), max(1.2, s * .006))
        pen.setDashPattern([2.0, 5.0])
        pen.setDashOffset(ph * 18)
        p.setPen(pen)
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(QPointF(cx, cy), R * 1.08, R * 1.08)
        # dönen yaylar
        for j in range(3):
            pen = QPen(qc(col.name(), .95), max(2.0, s * .012), Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
            p.setPen(pen)
            rect = QRectF(cx - R * .92, cy - R * .92, R * 1.84, R * 1.84)
            p.drawArc(rect, int(-(ph * 40 + j * 120) * 16), int(62 * 16))
        pen = QPen(qc(col.name(), .6), max(1.0, s * .005))
        p.setPen(pen)
        rect = QRectF(cx - R * .74, cy - R * .74, R * 1.48, R * 1.48)
        for j in range(2):
            p.drawArc(rect, int((ph * 55 + j * 180) * 16), int(110 * 16))
        # altıgen
        poly = QPolygonF()
        for i in range(6):
            a = i / 6 * 2 * math.pi - ph * .3
            poly.append(QPointF(cx + R * .52 * math.cos(a), cy + R * .52 * math.sin(a)))
        p.setPen(QPen(qc(col.name(), .8), max(1.2, s * .006)))
        p.drawPolygon(poly)
        # çekirdek
        cr = R * (.40 + .05 * math.sin(ph * 2) + .16 * lv)
        g = QRadialGradient(cx, cy, cr)
        g.setColorAt(0, QColor(255, 255, 255, 245))
        g.setColorAt(.35, mix(col, QColor("white"), .45))
        g.setColorAt(1, qc(col.name(), 0))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(g)
        p.drawEllipse(QPointF(cx, cy), cr, cr)


# ====================================================================== SOHBET
class Bubble(QFrame):
    def __init__(self, text, who):
        super().__init__()
        self.who = who
        self.setObjectName({"user": "bubU", "jarvis": "bubJ"}.get(who, "bubS"))
        lay = QVBoxLayout(self)
        lay.setContentsMargins(14, 9, 14, 10)
        self.lab = QLabel()
        self.lab.setWordWrap(True)
        self.lab.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.lab.setOpenExternalLinks(True)
        self.set_text(text)
        lay.addWidget(self.lab)
        self.setMaximumWidth(560 if who != "sys" else 640)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground)

    def set_text(self, t):
        if self.who == "jarvis":
            self.lab.setTextFormat(Qt.TextFormat.MarkdownText)
        self.lab.setText(t)


class Chat(QScrollArea):
    def __init__(self):
        super().__init__()
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.inner = QWidget()
        self.inner.setObjectName("chatInner")
        self.lay = QVBoxLayout(self.inner)
        self.lay.setContentsMargins(6, 6, 10, 6)
        self.lay.setSpacing(10)
        self.lay.addStretch(1)
        self.setWidget(self.inner)
        self.viewport().setAutoFillBackground(False)
        self.kayit = []          # kalıcı kayıt için balonlar
        self.on_change = None    # yeni balon eklenince çağrılır (sohbet dosyasına yazılır)

    def add(self, text, who, kaydet=True, anim=True):
        b = Bubble(text, who)
        if kaydet:
            self.kayit.append(b)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        if who == "user":
            row.addStretch(1)
            row.addWidget(b)
        elif who == "sys":
            row.addStretch(1)
            row.addWidget(b)
            row.addStretch(1)
        else:
            row.addWidget(b)
            row.addStretch(1)
        self.lay.insertLayout(self.lay.count() - 1, row)
        if anim:
            eff = QGraphicsOpacityEffect(b)
            b.setGraphicsEffect(eff)
            an = QPropertyAnimation(eff, b"opacity", b)
            an.setDuration(350)
            an.setStartValue(0.0)
            an.setEndValue(1.0)
            an.finished.connect(lambda: b.setGraphicsEffect(None))
            an.start()
        QTimer.singleShot(60, self.bottom)
        if kaydet and self.on_change:
            self.on_change()
        return b

    def bottom(self):
        bar = self.verticalScrollBar()
        bar.setValue(bar.maximum())


# ====================================================================== SES GİRİŞ / ÇIKIŞ
class Mic(QObject):
    level = pyqtSignal(float)
    heard = pyqtSignal(bytes)
    gave_up = pyqtSignal()
    error = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.stop = threading.Event()
        self.th = None

    @staticmethod
    def available():
        try:
            import sounddevice  # noqa
            import numpy  # noqa
            return True
        except Exception:
            return False

    def listen(self, bekle=9.0, sonsuz=False):
        self.cancel()
        self.stop = threading.Event()
        self.th = threading.Thread(target=self._run, args=(self.stop, bekle, sonsuz), daemon=True)
        self.th.start()

    def cancel(self):
        self.stop.set()

    def _run(self, stop, bekle, sonsuz):
        try:
            import sounddevice as sd
            import numpy as np
            from collections import deque
            sr, blk = 16000, 480
            with sd.InputStream(samplerate=sr, channels=1, dtype="int16", blocksize=blk) as st:
                amb = []
                for _ in range(10):
                    d, _o = st.read(blk)
                    amb.append(float(np.sqrt(np.mean(d.astype(np.float32) ** 2))))
                thr = max(110.0, (sum(amb) / len(amb)) * 2.6)
                pre = deque(maxlen=10)
                frames, speaking, cnt = [], False, 0
                t0 = time.time()
                voiced = 0
                last_voice = 0.0
                while not stop.is_set():
                    d, _o = st.read(blk)
                    rms = float(np.sqrt(np.mean(d.astype(np.float32) ** 2)))
                    self.level.emit(min(1.0, rms / 5000))
                    now = time.time()
                    if not speaking:
                        pre.append(d.copy())
                        cnt = cnt + 1 if rms > thr else 0
                        if cnt >= 3:
                            speaking, frames, voiced, last_voice = True, list(pre), 0, now
                        elif not sonsuz and now - t0 > bekle:
                            self.level.emit(0.0)
                            self.gave_up.emit()
                            return
                    else:
                        frames.append(d.copy())
                        if rms > thr:
                            last_voice = now
                            voiced += 1
                        if now - last_voice > 1.05 or len(frames) > 16000 / blk * 28:
                            if voiced >= 8:  # ~0.25 sn gerçek ses
                                arr = np.concatenate(frames).astype(np.float32)
                                pk = float(np.max(np.abs(arr))) or 1.0
                                arr = arr * min(40.0, 22000.0 / pk)  # kısık mikrofonu yükselt
                                pcm = np.clip(arr, -32000, 32000).astype(np.int16).tobytes()
                                buf = io.BytesIO()
                                with wave.open(buf, "wb") as wf:
                                    wf.setnchannels(1)
                                    wf.setsampwidth(2)
                                    wf.setframerate(sr)
                                    wf.writeframes(pcm)
                                self.level.emit(0.0)
                                self.heard.emit(buf.getvalue())
                                return
                            speaking, frames, cnt = False, [], 0
            self.level.emit(0.0)
        except Exception as e:
            self.level.emit(0.0)
            self.error.emit("Mikrofon açılamadı: %s" % e)


class Speaker(QObject):
    finished = pyqtSignal()
    hata = pyqtSignal(str)
    _play = pyqtSignal(str)

    def __init__(self, cfg):
        super().__init__()
        self.cfg, self.tok, self.proc, self.player, self.cur = cfg, 0, None, None, None
        self._play.connect(self._do_play)
        self.tried = False

    def _ensure(self):
        """Oynatıcıyı ilk konuşmada, ses çıkış cihazı varsa kurar (cihaz yoksa Qt çökebilir)."""
        if self.tried:
            return self.player is not None
        self.tried = True
        try:
            from PyQt6.QtMultimedia import QMediaPlayer, QAudioOutput, QMediaDevices
            if not QMediaDevices.audioOutputs():
                return False
            self.player = QMediaPlayer()
            self.out = QAudioOutput()
            self.out.setVolume(1.0)
            self.player.setAudioOutput(self.out)
            self.player.mediaStatusChanged.connect(self._status)
            self.player.errorOccurred.connect(lambda *a: self._done())
            self.QMP = QMediaPlayer
        except Exception:
            self.player = None
        return self.player is not None

    @staticmethod
    def temizle(t):
        import re
        t = re.sub(r"```.*?```", " ", t, flags=re.S)
        t = re.sub(r"https?://\S+", " bağlantı ", t)
        t = re.sub(r"[*_`#>|~]+", "", t)
        t = re.sub(r"^\s*[-•]\s+", "", t, flags=re.M)
        t = re.sub(r"\s+", " ", t).strip()
        if len(t) > 650:
            cut = t[:650]
            i = max(cut.rfind(". "), cut.rfind("! "), cut.rfind("? "))
            t = cut[:i + 1] if i > 200 else cut
        return t

    def say(self, text):
        self.stop()
        t = self.temizle(text)
        if not t:
            self.finished.emit()
            return
        tok = self.tok
        threading.Thread(target=self._gen, args=(t, tok), daemon=True).start()

    def stop(self):
        self.tok += 1
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.kill()
        except Exception:
            pass
        if self.player:
            try:
                self.player.stop()
            except Exception:
                pass

    def _gen(self, t, tok):
        path = None
        try:
            import asyncio
            import edge_tts
            hiz = int(self.cfg["hiz"]) + PROFILLER.get(self.cfg["profil"], {"rate": 0})["rate"]
            path = os.path.join(tempfile.gettempdir(), "jarvis_%d.mp3" % int(time.time() * 1000))

            async def go():
                ses_id, ek = ses_ayari(self.cfg["ses"])
                await edge_tts.Communicate(t, ses_id, rate="%+d%%" % hiz, **ek).save(path)
            asyncio.run(go())
            if tok != self.tok:
                return
            self._ready = path
            self._play.emit(path)
            return
        except Exception as e:
            self.hata.emit("Ses motoru (edge-tts) çalışmadı: %s. Yedek Windows sesi deneniyor." % e)
        # yedek: Windows'un kendi sesi
        if sys.platform == "win32":
            try:
                env = dict(os.environ, JV_TEXT=t)
                self.proc = subprocess.Popen(
                    ["powershell", "-NoProfile", "-Command",
                     "Add-Type -AssemblyName System.Speech;$s=New-Object System.Speech.Synthesis.SpeechSynthesizer;"
                     "$s.Speak($env:JV_TEXT)"], env=env, creationflags=0x08000000)
                self.proc.wait()
            except Exception:
                pass
        if tok == self.tok:
            self.finished.emit()

    def _do_play(self, path):
        # ana iş parçacığında çalışır (Qt nesneleri burada oluşturulur)
        if not self._ensure():
            self.hata.emit("Ses çıkış cihazı bulunamadı ya da oynatıcı açılamadı.")
            try:
                os.remove(path)
            except Exception:
                pass
            self.finished.emit()
            return
        self.cur = path
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()

    def _status(self, st):
        if st == self.QMP.MediaStatus.EndOfMedia:
            self._done()

    def _done(self):
        if self.cur:
            try:
                os.remove(self.cur)
            except Exception:
                pass
            self.cur = None
        self.finished.emit()


# ====================================================================== BEYİN ↔ ARAYÜZ
class Hooks(QObject):
    sig_say = pyqtSignal(str, bool)
    sig_durum = pyqtSignal(str)
    sig_ekran = pyqtSignal(bool)
    sig_onay = pyqtSignal(str)
    sig_bg = pyqtSignal(dict)
    sig_done = pyqtSignal(str, bool)
    sig_wake = pyqtSignal(object)   # None: uyanma yok | "": sadece 'Jarvis' | metin: komut
    sig_profil = pyqtSignal(str)

    def __init__(self):
        super().__init__()
        self.ans, self.ev = False, threading.Event()

    def say(self, t, final=False):
        self.sig_say.emit(t, final)

    def durum(self, t):
        self.sig_durum.emit(t)

    def ekran_modu(self, on):
        self.sig_ekran.emit(bool(on))

    def arka_plan(self, d):
        self.sig_bg.emit(d)

    def profil(self, p):
        self.sig_profil.emit(p)

    def onay(self, msg):
        self.ev.clear()
        self.ans = False
        self.sig_onay.emit(msg)
        self.ev.wait(180)
        return self.ans


# ====================================================================== KÜÇÜK HUD
class Hud(QWidget):
    def __init__(self, cfg):
        super().__init__(None, Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint |
                         Qt.WindowType.Tool | Qt.WindowType.WindowTransparentForInput)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setAttribute(Qt.WidgetAttribute.WA_ShowWithoutActivating)
        self.resize(210, 250)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 6)
        self.orb = Orb(cfg)
        lay.addWidget(self.orb, 1)
        self.lab = QLabel("Çalışıyor…")
        self.lab.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.lab.setStyleSheet("color:#fff;background:rgba(5,10,20,190);border-radius:11px;padding:5px 10px;"
                               "font:600 10pt 'Segoe UI';")
        lay.addWidget(self.lab)
        hint = QLabel("Durdurmak için ESC")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        hint.setStyleSheet("color:rgba(255,255,255,170);font:8pt 'Segoe UI';background:transparent;")
        lay.addWidget(hint)

    def place(self):
        g = QApplication.primaryScreen().availableGeometry()
        self.move(g.right() - self.width() - 18, g.bottom() - self.height() - 18)


# ====================================================================== AYAR PENCERELERİ
class AyarDlg(QDialog):
    def __init__(self, cfg, parent=None, mesaj=""):
        super().__init__(parent)
        self.cfg = cfg
        self.setWindowTitle("Ayarlar")
        self.setMinimumWidth(520)
        v = QVBoxLayout(self)
        if mesaj:
            m = QLabel(mesaj)
            m.setWordWrap(True)
            m.setObjectName("warn")
            v.addWidget(m)
        f = QFormLayout()
        f.setLabelAlignment(Qt.AlignmentFlag.AlignRight)
        self.key = QLineEdit(cfg["api_key"])
        self.key.setEchoMode(QLineEdit.EchoMode.Password)
        self.key.setPlaceholderText("AIza...")
        kb = QHBoxLayout()
        kb.addWidget(self.key, 1)
        b1 = QPushButton("Göster")
        b1.setCheckable(True)
        b1.toggled.connect(lambda x: self.key.setEchoMode(QLineEdit.EchoMode.Normal if x else QLineEdit.EchoMode.Password))
        kb.addWidget(b1)
        bk = kopru.belgem_anahtar()
        if bk:
            b2 = QPushButton("Belgem'deki anahtarı kullan")
            b2.clicked.connect(lambda: self.key.setText(bk))
            kb.addWidget(b2)
        f.addRow("Gemini API anahtarı", kb)
        lnk = QLabel('<a href="https://aistudio.google.com/app/apikey">aistudio.google.com/app/apikey</a> adresinden ücretsiz alabilirsiniz.')
        lnk.setOpenExternalLinks(True)
        lnk.setObjectName("muted")
        f.addRow("", lnk)
        self.model = QComboBox()
        self.model.setEditable(True)
        self.model.addItems(MODELS)
        self.model.setCurrentText(cfg["model"])
        f.addRow("Model", self.model)
        self.think = QComboBox()
        self.think.addItems(["minimal", "medium", "high"])
        self.think.setCurrentText(cfg["thinking"] if cfg["thinking"] in ("minimal", "medium", "high") else "medium")
        f.addRow("Düşünme seviyesi", self.think)
        self.ad = QLineEdit(cfg["ad"])
        f.addRow("Asistan adı", self.ad)
        self.hitap = QLineEdit(cfg["hitap"])
        f.addRow("Size hitabı", self.hitap)
        self.ses_on = QCheckBox("Sesli yanıt ver")
        self.ses_on.setChecked(cfg["ses_acik"])
        f.addRow("Ses", self.ses_on)
        self.ses = QComboBox()
        self.ses.setEditable(True)
        for v in VOICES:
            self.ses.addItem(VOICE_LABELS.get(v, v), v)
        self.ses.setCurrentIndex(max(0, self.ses.findData(cfg["ses"])))
        f.addRow("Ses karakteri", self.ses)
        self.hiz = QSpinBox()
        self.hiz.setRange(-50, 50)
        self.hiz.setSuffix(" %")
        self.hiz.setValue(int(cfg["hiz"]))
        f.addRow("Konuşma hızı", self.hiz)
        self.guv = QCheckBox("Tehlikeli komutlardan önce (silme, kapatma…) onay iste")
        self.guv.setChecked(cfg["guvenli"])
        f.addRow("Güvenlik", self.guv)
        self.sur = QCheckBox("Sürekli dinle (konuşma modu)")
        self.sur.setChecked(cfg["surekli_dinle"])
        f.addRow("Mikrofon", self.sur)
        self.uyan = QCheckBox("'%s' deyince uyan (hands-free)" % cfg["ad"])
        self.uyan.setChecked(cfg["uyandirma"])
        f.addRow("", self.uyan)
        self.arayagir = QCheckBox("Jarvis konuşurken araya gir ve sustur (kulaklık önerilir)")
        self.arayagir.setChecked(cfg["araya_gir"])
        f.addRow("", self.arayagir)
        self.profil_c = QComboBox()
        for k, pv in PROFILLER.items():
            self.profil_c.addItem(pv["ad"], k)
        self.profil_c.setCurrentIndex(max(0, self.profil_c.findData(cfg["profil"])))
        f.addRow("Kişilik", self.profil_c)
        self.gmodel = QLineEdit(cfg["gorsel_model"])
        f.addRow("Resim modeli", self.gmodel)
        v.addLayout(f)
        mel = QHBoxLayout()
        self.dur = QLabel("")
        self.dur.setObjectName("muted")
        self.dur.setText(self.entegrasyon())
        mel.addWidget(self.dur, 1)
        bm = QPushButton("Melodi bağlantısını onar")
        bm.clicked.connect(lambda: self.dur.setText(self.entegrasyon(True)))
        mel.addWidget(bm)
        v.addLayout(mel)
        v.addSpacing(6)
        row = QHBoxLayout()
        row.addStretch(1)
        iptal = QPushButton("Vazgeç")
        iptal.clicked.connect(self.reject)
        ok = QPushButton("Kaydet")
        ok.setObjectName("primary")
        ok.setDefault(True)
        ok.clicked.connect(self.kaydet)
        row.addWidget(iptal)
        row.addWidget(ok)
        v.addLayout(row)

    @staticmethod
    def entegrasyon(onar=False):
        r = kopru.melodi_yama() if onar else ""
        m = "Melodi: " + ("kurulu" if kopru.melodi_kurulu() else "bulunamadı")
        b = "Belgem: " + ("kurulu" if kopru.belgem_kurulu() else "bulunamadı")
        return "%s  ·  %s  %s" % (m, b, r)

    def kaydet(self):
        c = self.cfg
        c["api_key"] = self.key.text().strip()
        c["model"] = self.model.currentText().strip() or MODELS[0]
        c["thinking"] = self.think.currentText()
        c["ad"] = self.ad.text().strip() or "Jarvis"
        c["hitap"] = self.hitap.text().strip() or "Efendim"
        c["ses_acik"] = self.ses_on.isChecked()
        c["ses"] = self.ses.currentData() or self.ses.currentText().strip() or VOICES[0]
        c["hiz"] = self.hiz.value()
        c["guvenli"] = self.guv.isChecked()
        c["surekli_dinle"] = self.sur.isChecked()
        c["uyandirma"] = self.uyan.isChecked()
        c["araya_gir"] = self.arayagir.isChecked()
        c["profil"] = self.profil_c.currentData() or "resmi"
        c["gorsel_model"] = self.gmodel.text().strip() or "gemini-2.5-flash-image"
        c.save()
        self.accept()


class ArkaPlanDlg(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.m = main
        self.setWindowTitle("Arka plan")
        self.setMinimumWidth(460)
        v = QVBoxLayout(self)
        v.addWidget(self.baslik("Hazır temalar"))
        g = QGridLayout()
        for i, (ad, t) in enumerate(TEMALAR.items()):
            b = QPushButton(ad)
            b.clicked.connect(lambda _=False, t=t: main.bg_uygula(dict(t)))
            g.addWidget(b, i // 3, i % 3)
        v.addLayout(g)
        v.addWidget(self.baslik("Stil"))
        g2 = QGridLayout()
        for i, (k, ad) in enumerate(STILLER):
            b = QPushButton(ad)
            b.clicked.connect(lambda _=False, k=k: self.stil(k))
            g2.addWidget(b, i // 3, i % 3)
        v.addLayout(g2)
        v.addWidget(self.baslik("Renkler"))
        r = QHBoxLayout()
        for key, ad in (("vurgu", "Vurgu"), ("renk1", "Zemin 1"), ("renk2", "Zemin 2")):
            b = QPushButton(ad)
            b.clicked.connect(lambda _=False, key=key: self.renk(key))
            r.addWidget(b)
        v.addLayout(r)
        v.addWidget(self.baslik("Kendi resmin"))
        r2 = QHBoxLayout()
        bi = QPushButton("Resim seç…")
        bi.clicked.connect(self.resim)
        r2.addWidget(bi)
        bw = QPushButton("Windows duvar kağıdı yap")
        bw.clicked.connect(self.duvar)
        r2.addWidget(bw)
        v.addLayout(r2)
        sl = QHBoxLayout()
        sl.addWidget(QLabel("Karartma"))
        self.sl = QSlider(Qt.Orientation.Horizontal)
        self.sl.setRange(0, 90)
        self.sl.setValue(int(main.cfg["bg"].get("karart", 55)))
        self.sl.valueChanged.connect(lambda x: main.bg_uygula({"karart": x}))
        sl.addWidget(self.sl, 1)
        v.addLayout(sl)
        h = QLabel("İpucu: \"Jarvis, arka planı kırmızı siberpunk yap\" demen yeterli.")
        h.setObjectName("muted")
        v.addWidget(h)

    @staticmethod
    def baslik(t):
        l = QLabel(t)
        l.setObjectName("sec")
        return l

    def stil(self, k):
        self.m.bg_uygula({"stil": k})

    def renk(self, key):
        c = QColorDialog.getColor(QColor(self.m.cfg["bg"][key]), self, "Renk seç")
        if c.isValid():
            self.m.bg_uygula({key: c.name()})

    def resim(self):
        f, _ = QFileDialog.getOpenFileName(self, "Resim seç", str(Path.home() / "Pictures"),
                                           "Resimler (*.png *.jpg *.jpeg *.bmp *.webp)")
        if f:
            self.m.bg_uygula({"stil": "resim", "resim": f})

    def duvar(self):
        f = self.m.cfg["bg"].get("resim")
        if not f:
            f, _ = QFileDialog.getOpenFileName(self, "Duvar kağıdı", str(Path.home() / "Pictures"),
                                               "Resimler (*.png *.jpg *.jpeg *.bmp)")
        if f:
            r = self.m.brain.t_duvar_kagidi(f)
            self.m.chat.add("Duvar kağıdı güncellendi." if r.get("tamam") else "Duvar kağıdı değiştirilemedi.", "sys")


# ====================================================================== ANA PENCERE
class Main(Canvas):
    def __init__(self, cfg):
        super().__init__(cfg)
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setWindowTitle(APP_NAME)
        self.resize(1180, 740)
        self.setMinimumSize(900, 600)
        self.busy, self.state, self.voice_bubble = False, "idle", None
        self.hooks = Hooks()
        self.brain = Beyin(cfg, self.hooks)
        self.mic, self.speaker, self.hud = Mic(), Speaker(cfg), Hud(cfg)
        self.hooks.sig_say.connect(self.on_say)
        self.hooks.sig_durum.connect(self.on_durum)
        self.hooks.sig_ekran.connect(self.on_ekran)
        self.hooks.sig_onay.connect(self.on_onay)
        self.hooks.sig_bg.connect(self.bg_uygula)
        self.hooks.sig_done.connect(self.on_done)
        self.hooks.sig_wake.connect(self.on_wake)
        self.hooks.sig_profil.connect(self.on_profil)
        self.mic.level.connect(self.on_level)
        self.mic.heard.connect(self.on_heard)
        self.mic.gave_up.connect(self.on_gave_up)
        self.mic.error.connect(self.on_mic_error)
        self.speaker.finished.connect(self.on_spoken)
        self.speaker.hata.connect(lambda m: self.chat.add(m, "sys"))
        self.ekler = []            # gönderilmeyi bekleyen dosya/ekran parçaları
        self.elle = False          # mikrofon düğmesiyle başlatılan tek seferlik dinleme (uyanma sözcüğü gerekmez)
        self.uyandi_until = 0.0    # uyandıktan sonra kısa süre sözcüksüz konuşulabilir
        self.muzik = MuzikAnaliz()
        self.setAcceptDrops(True)
        self.build()
        self.restyle()
        self.sohbeti_yukle()
        self.chat.on_change = self.kaydet_sohbet
        self.on_profil(cfg["profil"])
        self.muzik_t = QTimer(self)
        self.muzik_t.timeout.connect(self.on_muzik_tick)
        self.muzik_t.start(700)
        self.esc_t = QTimer(self)
        self.esc_t.timeout.connect(self.esc_kontrol)
        self.esc_t.start(120)
        self.chat.add("Sistemler çevrimiçi. Emrinizi bekliyorum, %s." % cfg["hitap"], "jarvis")
        threading.Thread(target=self.arka_kurulum, daemon=True).start()
        if not cfg["api_key"]:
            QTimer.singleShot(500, lambda: self.ayarlar("Başlamak için bir Gemini API anahtarı gerekiyor."))
        elif cfg["surekli_dinle"] or cfg["uyandirma"]:
            QTimer.singleShot(800, lambda: self.dinle(True))

    # ---------- yapı
    def build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)
        # başlık çubuğu
        tb = QWidget()
        tb.setObjectName("tb")
        tb.setFixedHeight(46)
        self.tb = tb
        tl = QHBoxLayout(tb)
        tl.setContentsMargins(20, 0, 10, 0)
        self.title = QLabel(APP_NAME)
        self.title.setObjectName("title")
        tl.addWidget(self.title)
        self.sub = QLabel("● ÇEVRİMİÇİ")
        self.sub.setObjectName("sub")
        tl.addWidget(self.sub)
        tl.addStretch(1)
        for txt, fn, name in (("—", self.showMinimized, "wb"), ("▢", self.toggle_max, "wb"), ("✕", self.kapat, "wbx")):
            b = QPushButton(txt)
            b.setObjectName(name)
            b.setFixedSize(40, 30)
            b.clicked.connect(fn)
            tl.addWidget(b)
        root.addWidget(tb)
        body = QHBoxLayout()
        body.setContentsMargins(22, 6, 22, 22)
        body.setSpacing(22)
        root.addLayout(body, 1)
        # sol: orb
        left = QVBoxLayout()
        left.setSpacing(8)
        body.addLayout(left, 0)
        self.orb = Orb(self.cfg)
        self.orb.setMinimumWidth(330)
        left.addWidget(self.orb, 1)
        self.status = QLabel(DURUM["idle"])
        self.status.setObjectName("status")
        self.status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        left.addWidget(self.status)
        self.sure = QPushButton("∞  Sürekli dinle")
        self.sure.setCheckable(True)
        self.sure.setChecked(self.cfg["surekli_dinle"])
        self.sure.toggled.connect(self.surekli)
        left.addWidget(self.sure)
        self.uyan_b = QPushButton("◉  'Jarvis' deyince uyan")
        self.uyan_b.setCheckable(True)
        self.uyan_b.setChecked(self.cfg["uyandirma"])
        self.uyan_b.setToolTip("Açıkken 'Jarvis' diyerek hands-free uyandırırsın (konuşmalar Gemini'ye gider)")
        self.uyan_b.toggled.connect(self.uyandirma_ayarla)
        left.addWidget(self.uyan_b)
        chips = QGridLayout()
        chips.setSpacing(8)
        for i, (t, cmd) in enumerate((("🖥  Ekranda ne var?", "Ekranıma bak ve ne olduğunu kısaca anlat."),
                                      ("🎵  Müzik çal", "Melodi'den bir şarkı çal."),
                                      ("📄  Belge yaz", "Belgem'de bir belge oluşturmanı istiyorum."),
                                      ("🎨  Arka plan", "Arka planı sen seç ve değiştir."))):
            b = QPushButton(t)
            b.setObjectName("chip")
            b.clicked.connect(lambda _=False, c=cmd: self.submit(c))
            chips.addWidget(b, i // 2, i % 2)
        hb = QPushButton("📷  Ekranı gönder: hatayı çöz")
        hb.setObjectName("chip")
        hb.clicked.connect(lambda _=False: self.ekran_ekle("Ekrandaki hatayı tespit et ve nasıl çözeceğimi kısaca anlat."))
        chips.addWidget(hb, 2, 0, 1, 2)
        left.addLayout(chips)
        # sağ: sohbet
        glass = QFrame()
        glass.setObjectName("glass")
        body.addWidget(glass, 1)
        gl = QVBoxLayout(glass)
        gl.setContentsMargins(18, 16, 18, 16)
        gl.setSpacing(12)
        self.chat = Chat()
        gl.addWidget(self.chat, 1)
        row = QHBoxLayout()
        row.setSpacing(8)
        self.inp = QLineEdit()
        self.inp.setPlaceholderText("Bir komut yazın veya mikrofona konuşun…")
        self.inp.setMinimumHeight(44)
        self.inp.returnPressed.connect(self.gonder)
        row.addWidget(self.inp, 1)
        self.mic_b = self.ikon("🎙", "Konuş (tek seferlik)", self.mic_tikla)
        self.mic_b.setCheckable(True)
        self.send_b = self.ikon("➤", "Gönder", self.gonder)
        self.send_b.setObjectName("primary")
        self.stop_b = self.ikon("■", "Durdur (ESC)", self.durdur)
        self.stop_b.setObjectName("danger")
        self.stop_b.hide()
        self.dosya_b = self.ikon("📎", "Dosya ekle (ya da pencereye sürükle: PDF, Word, Excel, resim)", self.dosya_sec)
        self.ekran_b = self.ikon("📷", "Ekran görüntüsü ekle (Ctrl+Shift+S)", lambda _=False: self.ekran_ekle())
        for b in (self.mic_b, self.send_b, self.stop_b, self.dosya_b, self.ekran_b,
                  self.ikon("🎭", "Kişilik değiştir (resmi → esprili → sert → sakin)", self.profil_dongu),
                  self.ikon("🎨", "Arka plan", self.bg_penceresi),
                  self.ikon("⚙", "Ayarlar", lambda: self.ayarlar())):
            row.addWidget(b)
        sc = QShortcut(QKeySequence("Ctrl+Shift+S"), self)
        sc.activated.connect(lambda: self.ekran_ekle())
        gl.addLayout(row)
        self.grip = QSizeGrip(self)
        self.grip.setFixedSize(18, 18)
        if not Mic.available():
            self.mic_b.setEnabled(False)
            self.mic_b.setToolTip("Mikrofon için sounddevice kurulu değil")

    def ikon(self, t, tip, fn):
        b = QPushButton(t)
        b.setToolTip(tip)
        b.setFixedSize(44, 44)
        b.clicked.connect(fn)
        return b

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self.grip.move(self.width() - 20, self.height() - 20)

    def restyle(self):
        a = self.cfg["bg"]["vurgu"]
        self.setStyleSheet("""
        * { font-family:'Segoe UI','Inter',sans-serif; font-size:10.5pt; color:#e8f3ff; }
        #tb { background:transparent; }
        #title { font-size:13pt; font-weight:700; letter-spacing:5px; color:%(a)s; }
        #sub { color:rgba(232,243,255,140); font-size:8pt; letter-spacing:2px; margin-left:14px; }
        #status { font-size:11pt; letter-spacing:2px; color:rgba(232,243,255,200); padding:2px 0 6px 0; }
        #glass { background:rgba(6,12,26,150); border:1px solid %(a40)s; border-radius:20px; }
        #chatInner { background:transparent; }
        QScrollArea { background:transparent; border:none; }
        QScrollBar:vertical { background:transparent; width:8px; margin:2px; }
        QScrollBar::handle:vertical { background:%(a40)s; border-radius:4px; min-height:30px; }
        QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
        #bubU { background:%(a22)s; border:1px solid %(a60)s; border-radius:16px; border-bottom-right-radius:4px; }
        #bubJ { background:rgba(255,255,255,16); border:1px solid rgba(255,255,255,34); border-radius:16px; border-bottom-left-radius:4px; }
        #bubS { background:transparent; border:none; }
        #bubS QLabel { color:rgba(232,243,255,120); font-size:9pt; }
        QLabel { background:transparent; }
        QLineEdit, QComboBox, QSpinBox { background:rgba(255,255,255,14); border:1px solid rgba(255,255,255,40);
            border-radius:14px; padding:8px 14px; selection-background-color:%(a)s; selection-color:#000; }
        QLineEdit:focus, QComboBox:focus { border:1px solid %(a)s; }
        QPushButton { background:rgba(255,255,255,16); border:1px solid rgba(255,255,255,40); border-radius:14px;
            padding:8px 14px; }
        QPushButton:hover { background:%(a22)s; border-color:%(a)s; }
        QPushButton:checked { background:%(a40)s; border-color:%(a)s; }
        QPushButton:disabled { color:rgba(255,255,255,70); }
        #primary { background:%(a)s; color:#02121a; border:none; font-weight:700; }
        #primary:hover { background:%(a)s; }
        #primary { color:#02121a; }
        #danger { background:rgba(255,59,78,200); border:none; font-weight:700; }
        #chip { text-align:left; padding:9px 12px; font-size:9.5pt; }
        #wb, #wbx { border:none; background:transparent; border-radius:8px; padding:0; font-size:11pt; }
        #wb:hover { background:rgba(255,255,255,30); }
        #wbx:hover { background:rgba(255,59,78,220); }
        QDialog { background:#0a1224; }
        QDialog QLabel#sec { color:%(a)s; font-weight:700; letter-spacing:2px; margin-top:8px; }
        QDialog QLabel#muted { color:rgba(232,243,255,130); font-size:9pt; }
        QDialog QLabel#warn { background:%(a22)s; border:1px solid %(a)s; border-radius:10px; padding:10px; }
        QCheckBox { spacing:8px; }
        QComboBox QAbstractItemView { background:#0d172c; border:1px solid %(a40)s; selection-background-color:%(a40)s; }
        QSlider::groove:horizontal { height:4px; background:rgba(255,255,255,40); border-radius:2px; }
        QSlider::handle:horizontal { background:%(a)s; width:16px; margin:-6px 0; border-radius:8px; }
        QMessageBox { background:#0a1224; }
        """ % dict(a=a, a22=rgba(a, .16), a40=rgba(a, .32), a60=rgba(a, .55)))

    # ---------- pencere
    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton and e.position().y() < self.tb.height():
            h = self.windowHandle()
            if h:
                h.startSystemMove()
        super().mousePressEvent(e)

    def mouseDoubleClickEvent(self, e):
        if e.position().y() < self.tb.height():
            self.toggle_max()

    def toggle_max(self):
        if self.isMaximized():
            self.showNormal()
            self.radius = 18
        else:
            self.showMaximized()
            self.radius = 0

    def kapat(self):
        self.brain.iptal = True
        self.mic.cancel()
        self.speaker.stop()
        self.muzik.dur()
        self.brain._gecmis_kaydet()
        self.kaydet_sohbet()
        self.cfg.save()
        self.hud.hide()
        QApplication.quit()

    def closeEvent(self, e):
        self.kapat()

    # ---------- durum
    def set_state(self, s):
        self.state = s
        self.orb.set_state(s)
        self.hud.orb.set_state(s)
        self.status.setText(DURUM[s].upper())
        self.mic_b.setChecked(s == "listening")
        self.stop_b.setVisible(self.busy or s == "speaking")
        self.send_b.setVisible(not self.busy)
        if s != "listening":
            self.orb.level = 0.0
        if s == "speaking":
            self.barge_dinle()

    def on_level(self, v):
        self.orb.level = v

    def on_durum(self, t):
        self.hud.lab.setText(t)
        if self.busy:
            self.status.setText(t.upper())
            self.set_state_quiet("acting" if "…" in t and not t.startswith("Düşün") else "thinking")

    def set_state_quiet(self, s):
        if self.state != s:
            self.state = s
            self.orb.set_state(s)
            self.hud.orb.set_state(s)

    def esc_kontrol(self):
        if self.busy and esc_basili() and time.time() - self.brain.son_tus > 1.2:
            self.durdur()

    # ---------- girdi
    def gonder(self):
        t = self.inp.text().strip()
        if t:
            self.inp.clear()
            self.submit(t)

    def mic_tikla(self):
        if self.state == "listening":
            self.mic.cancel()
            self.elle = False
            self.set_state("idle")
            self.mic_b.setChecked(False)
        else:
            self.elle = True
            self.dinle(False)

    def uyandirma_ayarla(self, on):
        self.cfg["uyandirma"] = bool(on)
        self.cfg.save()
        if on and not self.busy and self.state == "idle":
            self.dinle(True)
        elif not on and self.state == "listening" and not self.cfg["surekli_dinle"]:
            self.mic.cancel()
            self.set_state("idle")

    def barge_dinle(self):
        """Jarvis konuşurken mikrofonu açar; kullanıcı konuşursa sesi kesilir (araya girme)."""
        if self.cfg["araya_gir"] and self.cfg["api_key"] and Mic.available():
            self.mic.listen(sonsuz=True)

    def on_wake(self, sonuc):
        """Uyanma sözcüğü kontrolünün sonucu. None: uyanma yok, '': yalnızca 'Jarvis', metin: komut."""
        if sonuc is None:
            if self.cfg["uyandirma"] and not self.busy and self.state in ("idle", "listening"):
                self.dinle(True)
            return
        self.uyandi_until = time.time() + 25
        if sonuc == "":
            h = self.cfg["hitap"] + "?"
            self.chat.add(h, "jarvis")
            if self.cfg["ses_acik"]:
                self.set_state("speaking")
                self.speaker.say(h)
            else:
                self.set_state("idle")
                self.dinle(True)
        else:
            self.submit(sonuc)

    def _uyandir_kontrol(self, wav):
        try:
            sonuc = self.brain.uyandirma_kontrol(wav)
        except Exception:
            sonuc = None
        self.hooks.sig_wake.emit(sonuc)

    def surekli(self, on):
        self.cfg["surekli_dinle"] = bool(on)
        self.cfg.save()
        if on and not self.busy and self.state in ("idle",):
            self.dinle(True)
        elif not on and self.state == "listening":
            self.mic.cancel()
            self.set_state("idle")

    def dinle(self, sonsuz):
        if not Mic.available() or not self.cfg["api_key"]:
            self.mic_b.setChecked(False)
            if not self.cfg["api_key"]:
                self.ayarlar("Önce Gemini API anahtarını girin.")
            return
        if self.busy:
            return
        self.speaker.stop()
        self.set_state("listening")
        self.mic.listen(sonsuz=sonsuz)

    def on_gave_up(self):
        self.set_state("idle")
        self.chat.add("Ses algılanmadı. Windows'ta doğru mikrofonun varsayılan olduğunu ve izin verildiğini kontrol edin.", "sys")

    def on_mic_error(self, m):
        self.set_state("idle")
        self.sure.setChecked(False)
        self.chat.add(m, "sys")

    def on_heard(self, wav):
        if self.state == "speaking":                 # araya girildi: Jarvis'i sustur, sözünü al
            self.speaker.stop()
            self.set_state("idle")
            self.submit(None, wav)
            return
        if self.elle or not self.cfg["uyandirma"] or self.cfg["surekli_dinle"] or time.time() < self.uyandi_until:
            self.elle = False
            self.submit(None, wav)
            return
        threading.Thread(target=self._uyandir_kontrol, args=(wav,), daemon=True).start()

    def durdur(self):
        self.brain.iptal = True
        self.speaker.stop()
        self.mic.cancel()
        if not self.busy:
            self.set_state("idle")

    # ---------- görev
    def submit(self, text, audio=None):
        if self.busy:
            return
        if not self.cfg["api_key"]:
            self.ayarlar("Önce Gemini API anahtarını girin.")
            return
        self.speaker.stop()
        self.mic.cancel()
        ekler, self.ekler = self.ekler, []
        if audio:
            parts = ekler + [{"inlineData": {"mimeType": "audio/wav", "data": base64.b64encode(audio).decode()}},
                             {"text": "(Sesli mesaj. Sesi dinle; ilk satıra [DUYDUM: ...] yaz ve emri uygula.)"}]
            self.voice_bubble = self.chat.add("🎙  …", "user")
        else:
            if not text and ekler:
                text = "Eklediğim içeriği incele ve gerekeni yap."
            parts = ekler + [{"text": text}]
            self.voice_bubble = None
            self.chat.add(text + ("  📎" if ekler else ""), "user")
        self.busy = True
        self.set_state("thinking")
        threading.Thread(target=self._work, args=(parts,), daemon=True).start()

    def _work(self, parts):
        err = False
        try:
            final = self.brain.calistir(parts)
        except Exception as e:
            err = True
            final = str(e) or e.__class__.__name__
            try:
                (DATA / "hata.log").write_text(traceback.format_exc(), encoding="utf-8")
            except Exception:
                pass
        self.hooks.sig_done.emit(final or "", err)

    def temiz(self, text):
        """[DUYDUM: ..] / [BOS] etiketlerini işler. Dönüş: gösterilecek metin."""
        import re
        m = re.search(r"\[DUYDUM:\s*(.*?)\]", text, flags=re.S)
        if m and self.voice_bubble is not None:
            self.voice_bubble.set_text("🎙  " + m.group(1).strip())
            self.voice_bubble = None
        text = re.sub(r"\[DUYDUM:.*?\]", "", text, flags=re.S)
        if "[BOS]" in text:
            return ""
        return text.strip()

    def on_say(self, text, final):
        t = self.temiz(text)
        if t:
            self.chat.add(t, "jarvis")

    def on_done(self, text, err):
        self.busy = False
        QTimer.singleShot(0, self.kaydet_sohbet)
        ekran_acik_mi = self.hud.isVisible()
        if ekran_acik_mi:
            self.on_ekran(False)
        if self.voice_bubble is not None:
            if "[BOS]" in text or not text.strip():
                self.voice_bubble.set_text("🎙  (anlaşılamadı)")
                if not self.cfg["surekli_dinle"]:
                    self.chat.add("Sizi anlayamadım, tekrar eder misiniz?", "sys")
            self.voice_bubble = None
        t = self.temiz(text)
        if err:
            self.chat.add("⚠  " + t, "sys")
            self.set_state("idle")
            self.after_idle()
            return
        if not t:
            self.set_state("idle")
            self.after_idle()
            return
        self.chat.add(t, "jarvis")
        if self.cfg["ses_acik"] and t != "Durduruldu.":
            self.set_state("speaking")
            self.speaker.say(t)
        else:
            self.set_state("idle")
            self.after_idle()

    def on_spoken(self):
        if not (self.cfg["surekli_dinle"] or self.cfg["uyandirma"]):
            self.mic.cancel()          # araya girme dinlemesi konuşma bitince kapanır
        if self.state == "speaking":
            self.set_state("idle")
            self.after_idle()

    def after_idle(self):
        if (self.cfg["surekli_dinle"] or self.cfg["uyandirma"]) and not self.busy:
            QTimer.singleShot(350, lambda: self.dinle(True) if self.state == "idle" and not self.busy else None)

    # ---------- ekran modu / onay
    def on_ekran(self, on):
        if on:
            self.hud.place()
            self.hud.lab.setText("Ekrana bakıyor…")
            self.hud.show()
            self.hide()
        else:
            self.show()
            self.raise_()
            self.activateWindow()
            self.hud.hide()

    def on_onay(self, msg):
        vis = self.isVisible()
        if not vis:
            self.show()
            self.raise_()
        self.activateWindow()
        r = QMessageBox.question(self, "Onay gerekiyor", msg,
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                                 QMessageBox.StandardButton.No)
        if not vis:
            self.hide()
        self.hooks.ans = r == QMessageBox.StandardButton.Yes
        self.hooks.ev.set()

    # ---------- ekran / dosya girişi
    def ekran_ekle(self, metin=None):
        """Ekran görüntüsünü alır. metin verilirse hemen gönderir, verilmezse sonraki mesaja ekler."""
        if self.busy:
            return
        self.hide()
        QTimer.singleShot(400, lambda: self._yakala(metin if isinstance(metin, str) else None))

    def _yakala(self, metin):
        try:
            data = self.brain._shot(1280)
        except Exception:
            data = None
        self.show()
        self.raise_()
        self.activateWindow()
        if not data:
            self.chat.add("Ekran görüntüsü alınamadı.", "sys")
            return
        self.ekler.append({"inlineData": {"mimeType": "image/jpeg", "data": data}})
        if metin:
            self.submit(metin)
        else:
            self.chat.add("📷  Ekran görüntüsü eklendi. Ne yapmamı istersin?", "sys")

    def dosya_sec(self):
        f, _ = QFileDialog.getOpenFileName(self, "Dosya seç", str(Path.home()),
                                           "Belgeler (*.pdf *.docx *.xlsx *.xlsm *.csv *.txt *.md *.json "
                                           "*.png *.jpg *.jpeg *.webp);;Tümü (*)")
        if f:
            self.dosya_ekle(f)

    def dosya_ekle(self, yol):
        try:
            parts = dosya_parcalari(yol)
        except Exception as e:
            self.chat.add("Dosya eklenemedi: %s" % e, "sys")
            return
        self.ekler.extend(parts)
        if yol.lower().endswith(".docx"):
            self.brain.son_belge = yol
        self.chat.add("📎  %s eklendi. Ne yapmamı istersin?" % Path(yol).name, "sys")

    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        for u in e.mimeData().urls():
            if u.isLocalFile():
                self.dosya_ekle(u.toLocalFile())
        e.acceptProposedAction()

    # ---------- kişilik / müzik / sohbet kaydı
    def profil_dongu(self):
        keys = list(PROFILLER)
        cur = self.cfg["profil"] if self.cfg["profil"] in PROFILLER else keys[0]
        self.brain.t_profil_degistir(keys[(keys.index(cur) + 1) % len(keys)])

    def on_profil(self, p):
        ad = PROFILLER.get(p, {"ad": p})["ad"]
        self.sub.setText("● ÇEVRİMİÇİ · " + ad.upper())

    def on_muzik_tick(self):
        st = kopru.melodi_durum()
        calan = bool(st and st.get("playing"))
        if calan:
            self.muzik.basla()
        else:
            self.muzik.dur()
        self.orb.muzik = self.muzik if calan else None
        self.hud.orb.muzik = self.orb.muzik

    def sohbeti_yukle(self):
        try:
            veri = json.loads((DATA / "sohbet_ekrani.json").read_text(encoding="utf-8"))
        except Exception:
            return
        cb, self.chat.on_change = self.chat.on_change, None
        for metin, who in veri[-120:]:
            self.chat.add(str(metin), str(who), anim=False)
        self.chat.on_change = cb

    def kaydet_sohbet(self):
        try:
            veri = [[b.lab.text(), b.who] for b in self.chat.kayit[-200:]]
            yol = DATA / "sohbet_ekrani.json"
            tmp = yol.with_suffix(".tmp")
            tmp.write_text(json.dumps(veri, ensure_ascii=False), encoding="utf-8")
            os.replace(tmp, yol)
        except Exception:
            pass

    # ---------- ayarlar / arka plan
    def ayarlar(self, mesaj=""):
        d = AyarDlg(self.cfg, self, mesaj)
        if d.exec():
            self.sure.setChecked(self.cfg["surekli_dinle"])
            self.uyan_b.setChecked(self.cfg["uyandirma"])
            self.on_profil(self.cfg["profil"])
            self.chat.add("Ayarlar kaydedildi.", "sys")

    def bg_penceresi(self):
        ArkaPlanDlg(self).show()

    def bg_uygula(self, d):
        self.cfg["bg"].update({k: v for k, v in d.items() if v is not None})
        self.cfg.save()
        self.buf = None
        self.cols = []
        self.restyle()
        self.update()

    def arka_kurulum(self):
        try:
            kopru.melodi_yama()
        except Exception:
            pass


# ====================================================================== İKON
def orb_pixmap(size=256, accent="#27d3ff"):
    pm = QPixmap(size, size)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    c, R = size / 2, size * .40
    bgc = QRadialGradient(c, c, size * .52)
    bgc.setColorAt(0, QColor("#0d1a33"))
    bgc.setColorAt(1, QColor("#03060f"))
    p.setBrush(bgc)
    p.setPen(Qt.PenStyle.NoPen)
    p.drawRoundedRect(QRectF(0, 0, size, size), size * .22, size * .22)
    col = QColor(accent)
    for j in range(3):
        p.setPen(QPen(col, size * .035, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawArc(QRectF(c - R, c - R, 2 * R, 2 * R), int((30 + j * 120) * 16), int(80 * 16))
    p.setPen(QPen(qc(accent, .6), size * .015))
    p.drawEllipse(QPointF(c, c), R * .68, R * .68)
    g = QRadialGradient(c, c, R * .5)
    g.setColorAt(0, QColor("white"))
    g.setColorAt(.4, mix(col, QColor("white"), .4))
    g.setColorAt(1, qc(accent, 0))
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(g)
    p.drawEllipse(QPointF(c, c), R * .5, R * .5)
    p.end()
    return pm


def log_crash(t, v, tb):
    try:
        (DATA / "hata.log").write_text("".join(traceback.format_exception(t, v, tb)), encoding="utf-8")
    except Exception:
        pass


def main():
    sys.excepthook = log_crash
    app = QApplication(sys.argv)
    app.setApplicationName("Jarvis")
    if len(sys.argv) > 2 and sys.argv[1] == "--ikon":
        orb_pixmap(256).save(sys.argv[2], "ICO") or orb_pixmap(256).save(sys.argv[2] + ".png")
        return 0
    app.setWindowIcon(QIcon(orb_pixmap(256)))
    cfg = Cfg()
    w = Main(cfg)
    scr = app.primaryScreen().availableGeometry()
    w.move(scr.center().x() - w.width() // 2, scr.center().y() - w.height() // 2)
    w.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(main())
