@echo off
setlocal
chcp 65001 >nul
title Jarvis - Kur Beni
set "SRC=%~dp0"
set "APP=%LOCALAPPDATA%\Jarvis\app"
echo.
echo   ====  J.A.R.V.I.S. kuruluyor  ====
echo.
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY where python >nul 2>nul && set "PY=python"
if not defined PY (
  echo   Python bulunamadi, otomatik kuruluyor...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo   Python kuruldu. Bu pencereyi kapat ve "Kur Beni" dosyasina bir kez daha cift tikla.
  pause
  exit /b
)
if not exist "%SRC%jarvis.py" (
  echo   jarvis.py bulunamadi. Zip dosyasini once klasore cikar.
  pause
  exit /b 1
)
mkdir "%APP%" 2>nul
copy /y "%SRC%jarvis.py" "%APP%\jarvis.py" >nul
copy /y "%SRC%beyin.py" "%APP%\beyin.py" >nul
copy /y "%SRC%kopru.py" "%APP%\kopru.py" >nul
if not exist "%APP%\venv\Scripts\pythonw.exe" (
  echo   Ortam hazirlaniyor...
  %PY% -m venv "%APP%\venv" || goto :hata
)
echo   Gerekli bilesenler yukleniyor (sadece bu adimda internet gerekir)...
"%APP%\venv\Scripts\python.exe" -m pip install --quiet --upgrade pip
"%APP%\venv\Scripts\python.exe" -m pip install --quiet PyQt6 pillow mss pyautogui pyperclip python-docx || goto :hata
echo   Ses bilesenleri yukleniyor...
"%APP%\venv\Scripts\python.exe" -m pip install --quiet numpy sounddevice edge-tts
if errorlevel 1 echo   (Uyari: ses bilesenleri yuklenemedi. Jarvis yazili calisir; internet kontrol edip tekrar dene.)
echo   Kisayollar olusturuluyor...
"%APP%\venv\Scripts\python.exe" "%APP%\jarvis.py" --ikon "%APP%\jarvis.ico" >nul 2>nul
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; foreach($d in @([Environment]::GetFolderPath('Desktop'),[Environment]::GetFolderPath('Programs'))){$s=$w.CreateShortcut($d+'\Jarvis.lnk');$s.TargetPath='%APP%\venv\Scripts\pythonw.exe';$s.Arguments='\"%APP%\jarvis.py\"';$s.WorkingDirectory='%APP%';if(Test-Path '%APP%\jarvis.ico'){$s.IconLocation='%APP%\jarvis.ico'};$s.Save()}"
echo   Melodi ve Belgem baglantisi kontrol ediliyor...
"%APP%\venv\Scripts\python.exe" -c "import sys; sys.path.insert(0, r'%APP%'); import kopru; print('  Melodi:', kopru.melodi_yama()); print('  Belgem:', 'kurulu' if kopru.belgem_kurulu() else 'bulunamadi (sonradan kurarsan Jarvis kendisi baglanir)')"
echo.
echo   Kurulum tamam! Jarvis aciliyor...
echo   (Ilk acilista ayarlardan Gemini API anahtarini gir: aistudio.google.com/app/apikey)
start "" "%APP%\venv\Scripts\pythonw.exe" "%APP%\jarvis.py"
timeout /t 4 >nul
exit /b
:hata
echo.
echo   Bir hata olustu. Internet baglantini kontrol edip tekrar dene.
pause
exit /b 1
