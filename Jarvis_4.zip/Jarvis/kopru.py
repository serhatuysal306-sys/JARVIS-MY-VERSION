# -*- coding: utf-8 -*-
"""Jarvis <-> Melodi / Belgem köprüsü.

* Melodi : kurulu kopyasına küçük bir "köprü" eklenir (geri alınabilir, yedeği alınır);
           Jarvis komutları dosya üzerinden gönderir, Melodi yanıt olarak durumunu yazar.
* Belgem : DOCX dosyalarını Belgem ile açar / oluşturur / okur, Belgem'deki Gemini anahtarını bulur.
"""
import os
import sys
import json
import time
import subprocess
from pathlib import Path

IS_WIN = sys.platform == "win32"
APPDATA = Path(os.environ.get("APPDATA") or (Path.home() / ".config"))
LOCAL = Path(os.environ.get("LOCALAPPDATA") or (Path.home() / ".local" / "share"))

MELODI_HOME = Path(os.environ.get("MELODI_HOME") or (APPDATA / "Melodi"))
BELGEM_HOME = APPDATA / "Belgem"
MELODI_APP = LOCAL / "Melodi" / "app"
BELGEM_APP = LOCAL / "Belgem" / "app"

MARK_BEGIN = "# ===== JARVIS-KOPRU-BASLA ====="
MARK_END = "# ===== JARVIS-KOPRU-BITIS ====="

# Melodi içine eklenen kod (Melodi'nin kendi LIB / HOME / Main yapısını kullanır)
BRIDGE_CODE = MARK_BEGIN + r'''
def _jarvis_bridge(win):
    """Jarvis'in Melodi'yi yönetebilmesi için jarvis_cmd.json dosyasını izler."""
    import time as _t
    cmd_p, st_p = HOME / 'jarvis_cmd.json', HOME / 'jarvis_state.json'
    last = {'txt': '', 'at': 0.0}

    def find(q):
        q = (q or '').lower().strip()
        if not q:
            return None
        part = None
        for t in LIB.tracks.values():
            n = (t.get('name', '') + ' ' + t.get('artist', '')).lower()
            if q in n:
                return t['id']
            if part is None and all(w in n for w in q.split()):
                part = t['id']
        return part

    def run(c):
        a = c.get('action')
        if a == 'play':
            if c.get('playlist'):
                l = next((x for x in LIB.lists if c['playlist'].lower() in x['name'].lower()), None)
                if l:
                    ids = [i for i in l['tracks'] if i in LIB.tracks]
                    if ids:
                        win.queue = ids
                        win.play_idx(0)
                return
            tid = find(c.get('query'))
            ids = list(LIB.tracks.keys())
            if tid:
                win.queue = ids
                win.play_idx(ids.index(tid))
            elif not c.get('query'):
                win.toggle_play()
        elif a == 'pause':
            win.player.pause()
        elif a == 'resume':
            win.player.play()
        elif a == 'toggle':
            win.toggle_play()
        elif a == 'stop':
            win.player.stop()
        elif a == 'next':
            win.next(False)
        elif a == 'prev':
            win.prev()
        elif a == 'volume':
            win.set_volume(max(0, min(100, int(c.get('value', 50)))))
        elif a == 'shuffle':
            win.shuffle = bool(c.get('value', True))
            win.update_player()
        elif a == 'raise':
            win.showNormal()
            win.raise_()
            win.activateWindow()

    def tick():
        try:
            if cmd_p.exists():
                try:
                    c = json.loads(cmd_p.read_text(encoding='utf-8'))
                finally:
                    cmd_p.unlink()
                run(c)
        except Exception:
            pass
        try:
            from PyQt6.QtMultimedia import QMediaPlayer as _P
            playing = win.player.playbackState() == _P.PlaybackState.PlayingState
            cur = LIB.tracks.get(win.queue[win.qi]) if 0 <= win.qi < len(win.queue) else None
            st = dict(running=True, playing=playing, volume=int(round(float(S.volume) * 100)),
                      current=(cur or {}).get('name', ''), artist=(cur or {}).get('artist', ''))
            txt = json.dumps(st, ensure_ascii=False)
            now = _t.time()
            if txt != last['txt'] or now - last['at'] > 2:
                st['ts'] = now
                write_json(st_p, st)
                last['txt'], last['at'] = txt, now
        except Exception:
            pass

    t = QTimer(win)
    t.timeout.connect(tick)
    t.start(600)
    win._jarvis_timer = t
''' + MARK_END + "\n\n"


def _popen(args, cwd=None):
    flags = 0
    if IS_WIN:
        flags = 0x00000008 | 0x00000200  # DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP
    try:
        subprocess.Popen(args, cwd=cwd, creationflags=flags, close_fds=True,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return True
    except Exception:
        return False


def _pyw(appdir):
    p = appdir / "venv" / ("Scripts" if IS_WIN else "bin") / ("pythonw.exe" if IS_WIN else "python")
    return p if p.exists() else None


# ------------------------------------------------------------------ MELODI
def melodi_kurulu():
    return (MELODI_APP / "melodi.py").exists() and _pyw(MELODI_APP) is not None


def melodi_yama(geri_al=False):
    """Melodi'ye köprüyü ekler (idempotent). Dönen değer: açıklama metni."""
    f = MELODI_APP / "melodi.py"
    if not f.exists():
        return "Melodi kurulu değil."
    src = f.read_text(encoding="utf-8")
    has = MARK_BEGIN in src
    if geri_al:
        if not has:
            return "Köprü zaten yok."
        a, b = src.index(MARK_BEGIN), src.index(MARK_END) + len(MARK_END)
        src = src[:a] + src[b:].lstrip("\n")
        src = src.replace("    _jarvis_bridge(win)\n", "")
        f.write_text(src, encoding="utf-8")
        return "Köprü kaldırıldı."
    if has:
        return "Köprü hazır."
    anchor = "def main():"
    call_old = "    win = Main()\n    win.show()\n"
    if anchor not in src or call_old not in src:
        return "Melodi'nin bu sürümüne köprü eklenemedi."
    try:
        (MELODI_APP / "melodi.py.jarvis-yedek").write_text(src, encoding="utf-8")
    except Exception:
        pass
    src = src.replace(anchor, BRIDGE_CODE + anchor, 1)
    src = src.replace(call_old, call_old + "    _jarvis_bridge(win)\n", 1)
    f.write_text(src, encoding="utf-8")
    return "Köprü eklendi (Melodi'yi yeniden açınca etkin olur)."


def melodi_durum():
    """Çalışıyorsa durum sözlüğü, değilse None."""
    try:
        d = json.loads((MELODI_HOME / "jarvis_state.json").read_text(encoding="utf-8"))
        if time.time() - float(d.get("ts", 0)) < 4:
            return d
    except Exception:
        pass
    return None


def melodi_kutuphane():
    try:
        d = json.loads((MELODI_HOME / "library.json").read_text(encoding="utf-8"))
    except Exception:
        return [], []
    tracks = [(t.get("name", ""), t.get("artist", "")) for t in d.get("tracks", [])]
    lists = [l.get("name", "") for l in d.get("lists", [])]
    return tracks, lists


def melodi_ac(bekle=True):
    if melodi_durum():
        return True
    if not melodi_kurulu():
        return False
    melodi_yama()
    _popen([str(_pyw(MELODI_APP)), str(MELODI_APP / "melodi.py")], cwd=str(MELODI_APP))
    if bekle:
        for _ in range(40):
            time.sleep(0.4)
            if melodi_durum():
                return True
    return bool(melodi_durum())


def melodi_komut(action, **kw):
    """Melodi'ye komut gönderir, durumu döndürür."""
    if not melodi_kurulu():
        return {"hata": "Melodi kurulu değil. Önce Melodi'nin 'Kur Beni' dosyasını çalıştırın."}
    if not melodi_ac():
        return {"hata": "Melodi açılamadı."}
    cmd = dict(action=action, **{k: v for k, v in kw.items() if v not in (None, "")})
    p = MELODI_HOME / "jarvis_cmd.json"
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(cmd, ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, p)
    time.sleep(1.4)
    st = melodi_durum() or {}
    st.pop("ts", None)
    return st or {"bilgi": "Komut gönderildi."}


# ------------------------------------------------------------------ BELGEM
def belgem_kurulu():
    return (BELGEM_APP / "belgem.py").exists() and _pyw(BELGEM_APP) is not None


def belgem_ac(dosya=None):
    if not belgem_kurulu():
        return False
    args = [str(_pyw(BELGEM_APP)), str(BELGEM_APP / "belgem.py")]
    if dosya and os.path.exists(dosya):
        args.append(str(dosya))
    return _popen(args, cwd=str(BELGEM_APP))


def belgem_anahtar():
    try:
        d = json.loads((BELGEM_HOME / "ayar.json").read_text(encoding="utf-8"))
        return (d.get("gemini_key") or "").strip()
    except Exception:
        return ""


def belge_klasoru():
    d = Path.home() / "Documents" / "Jarvis"
    d.mkdir(parents=True, exist_ok=True)
    return d


def belge_olustur(dosya_adi, baslik, icerik):
    """Basit biçimli DOCX üretir: '# ' başlık, '## ' alt başlık, '- ' madde, boş satır paragraf."""
    from docx import Document
    from docx.shared import Pt
    name = "".join(c for c in (dosya_adi or baslik or "belge") if c not in '\\/:*?"<>|').strip() or "belge"
    if not name.lower().endswith(".docx"):
        name += ".docx"
    path = Path(dosya_adi) if os.path.isabs(str(dosya_adi or "")) else belge_klasoru() / name
    if path.suffix.lower() != ".docx":
        path = path.with_suffix(".docx")
    path.parent.mkdir(parents=True, exist_ok=True)
    doc = Document()
    st = doc.styles["Normal"]
    st.font.name = "Calibri"
    st.font.size = Pt(11)
    if baslik:
        doc.add_heading(baslik, level=1)
    for line in (icerik or "").splitlines():
        s = line.rstrip()
        if not s.strip():
            continue
        if s.startswith("### "):
            doc.add_heading(s[4:], level=3)
        elif s.startswith("## "):
            doc.add_heading(s[3:], level=2)
        elif s.startswith("# "):
            doc.add_heading(s[2:], level=1)
        elif s.lstrip().startswith(("- ", "* ", "• ")):
            doc.add_paragraph(s.lstrip()[2:], style="List Bullet")
        else:
            doc.add_paragraph(s)
    doc.save(str(path))
    return str(path)


def belge_oku(dosya, limit=20000):
    p = Path(dosya)
    if not p.exists():
        return None
    if p.suffix.lower() == ".docx":
        from docx import Document
        d = Document(str(p))
        parts = [x.text for x in d.paragraphs if x.text.strip()]
        for t in d.tables:
            for r in t.rows:
                parts.append(" | ".join(c.text.strip() for c in r.cells))
        txt = "\n".join(parts)
    else:
        txt = p.read_text(encoding="utf-8", errors="replace")
    return txt[:limit]
